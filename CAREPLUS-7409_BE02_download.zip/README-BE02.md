# CAREPLUS-7409 BE-02 — session-consumer integration patch

## Included
- Uses BE-01 documented `dgl.paCodes` Spring Session candidates instead of making a second Partner IAM call from `/auth/me`.
- Normalizes uppercase alphanumeric PA codes, deduplicates, validates against `CacheService.getDealer`, checks JWT country, natural-sorts, and preserves the previously active PA when it belongs to the same user.
- Writes allowed list, active PA, owner, version and created-at into the existing session. Retains BE-01 IAM status and candidate list.
- JWT decoder change from the earlier patch stops primary-only onboarding rejection.
- Adds a **disabled-by-default** dealer WebFilter skeleton for proxied calls.

## NOT production-ready — required before enabling
1. **BE-01 code has not been supplied.** Confirm its actual session keys and callback behavior, then replace the adapter literals with its `DealerPaSessionAttributes` constants.
2. **G-2 / Index contract missing.** Confirm exact BE-02 attribute names, version type, timestamps, owner user ID and session-rebuild policy.
3. **WebFilter needs security review.** Its proxy path exclusion is illustrative and MUST be replaced with explicit Gateway route matching; verify its placement relative to auth filters, handling of direct bearer-token sessions and CSRF, and use `ErrorResponseUtil` for the existing errorCode 1001 response schema.
4. **Redis hash rebuild tolerance not implemented.** `CacheService.getDealer` cannot distinguish absent record from missing whole hash. Add hash-presence / rebuild state signal and bounded retry. Preserve existing valid session on transient failures; never replace with empty list.
5. **Redis outage 503 mapping not complete.** Ensure `RedisException` propagates and is mapped to HTTP 503 for all routes, including `/auth/me`; existing generic controller catch currently masks it.
6. **Session writes must be persisted atomically with reactive `session.save()` where needed** and concurrency / version / owner checked.
7. **Flag-off semantics** need to preserve the existing primary-only authorization, not silently bypass the BE-02 gate.
8. **Tests**: previous tests were not run; update mocks for new AuthServiceImpl constructor, add filter/session/Redis regression tests, run full Gradle build and inspect XML because `ignoreFailures=true`.
9. Confirm format (`^[A-Z0-9]{1,10}$`) with PO, numerical vs natural sorting, and actual Redis `Dealer` JSON.
10. User Service `WebSecurityConfig.isValidDealer` change is BE-03a and must deploy with the Gateway decoder change.

## Caution
This is a *reviewable partial patch*, not a verified complete implementation of BE-02. The filter is OFF by default. Do not deploy enabled without addressing the above items.
