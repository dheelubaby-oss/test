# CAREPLUS-7409 BE-02 — ONE CONSOLIDATED REVIEW PACKAGE

**Status: INCOMPLETE / NOT MERGE-READY.** This archive consolidates the latest BE-02 session-based patch and the missing exception class from the older patch. It is NOT a complete implementation or a tested PR.

## Which earlier ZIPs to use?
Do not apply any of the three older ZIPs on top of this archive. This one supersedes them for review purposes. Do not delete files from your existing project merely because they are not in this archive; these are changed/new files only.

## What is included?
The latest BE-02 code for session candidate reading, Redis filtering, natural alphanumeric ordering, active-PA restoration, UserInfo integration, JWT decoder change, a provisional WebFilter, and existing validation tests. No Partner IAM provider/client is included: BE-01 owns retrieval. No obsolete fallback service or its test is included.

## Critical blockers before use
1. BE-01 actual implementation and shared G-2/Index session schema missing; adapter currently assumes session attribute names.
2. WebFilter is OFF by default and uses an illustrative route match and provisional 403 JSON; must use ErrorResponseUtil and verified protected-route rules. Filter order/security interactions unverified.
3. Hash rebuild retry/tolerance missing. Redis outages need consistent 503 mapping; do not clear an existing allowed list during transient errors.
4. Empty-list contract: BE-02 requires session established and 403/1001 on first proxied call; existing AuthController still handles NoEligibleDealershipException on /auth/me. This must be reconciled.
5. BE-02 flag-off behavior and first-call behavior need end-to-end validation.
6. Full tests (session ownership, restored active, feature flag, WebFilter, 403, 503, hash rebuild, bearer session, employee regression) not yet present.
7. AuthServiceImpl constructor compatibility with BE-01 callback changes and test constructors unverified.
8. User Service validator update is BE-03a; coordinate deployment.
9. No Gradle compilation or test run was possible from these partial project files. `test.ignoreFailures=true` means inspect XML reports.

**Do not deploy this archive as final.** The source story demands these remaining changes.
