package com.careplus.gatewayservice.service;

import com.careplus.gatewayservice.model.DealerPaDetails;
import com.careplus.gatewayservice.model.DealerPaValidationResult;
import reactor.core.publisher.Mono;

public interface DealerPaValidationService {
    Mono<DealerPaValidationResult> validateDealerPaCodes(DealerPaDetails details, String jwtCountryCode);
}
