package com.careplus.gatewayservice.exception;

public final class NoEligibleDealershipException extends RuntimeException {
    public NoEligibleDealershipException() { super("No eligible dealerships for this user"); }
}
