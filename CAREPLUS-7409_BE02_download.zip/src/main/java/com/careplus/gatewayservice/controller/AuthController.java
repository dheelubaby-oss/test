package com.careplus.gatewayservice.controller;

import com.careplus.gatewayservice.configs.auth.OAuthUriResolver;
import com.careplus.gatewayservice.constant.APIErrorCode;
import com.careplus.gatewayservice.exception.AuthFlowException;
import com.careplus.gatewayservice.exception.InvalidDomainException;
import com.careplus.gatewayservice.exception.InvalidStateException;
import com.careplus.gatewayservice.model.APIResponseVoid;
import com.careplus.gatewayservice.model.CallbackFormParams;
import com.careplus.gatewayservice.model.UserInfo;
import com.careplus.gatewayservice.model.UserSession;
import com.careplus.gatewayservice.service.AuthService;
import com.careplus.gatewayservice.util.ErrorResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.headers.Header;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirements;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebSession;
import reactor.core.publisher.Mono;

import java.net.URI;
import java.time.Duration;
import java.util.regex.Pattern;

import static com.careplus.gatewayservice.configs.SessionAuthenticationFilter.SESSION_COOKIE;
import static com.careplus.gatewayservice.constant.CommonConstant.AUTH;
import static com.careplus.gatewayservice.constant.CommonConstant.ATTR_API_END_DEBUG_AUTH_ME_INVALID_STATE;
import static com.careplus.gatewayservice.constant.CommonConstant.EVT_ME_NO_SESSION;
import static com.careplus.gatewayservice.constant.CommonConstant.EVT_ME_SESSION_READ_ERROR;
import static com.careplus.gatewayservice.serviceimpl.AuthServiceImpl.SESSION_ATTR_LOGIN_FLOW;
import static com.careplus.gatewayservice.serviceimpl.AuthServiceImpl.SESSION_ATTR_POST_LOGOUT_URI;

/**
 * BFF endpoints that drive the OAuth 2.0 Authorization Code + PKCE flow.
 *
 * <p>All four endpoints are permitted without authentication (see
 * {@code WebSecurityConfig#filterChain} — {@code pathMatchers(AUTH + "/**").permitAll()}).
 * Tokens never leave the server; the client receives only an opaque SESSION cookie
 * managed by Spring Session (HttpOnly, Secure, SameSite=None).</p>
 *
 * <h2>Dynamic URI construction</h2>
 * <p>The four OAuth URIs ({@code redirect_uri}, {@code post_login_redirect_uri},
 * {@code post_logout_redirect_uri}, {@code post_login_failure_uri}) are constructed at
 * runtime from the request's domain by {@link OAuthUriResolver}.  Only origins listed
 * in {@code oauth.allowed.domains} are accepted; unmatched domains are redirected to
 * the configured post-login failure URI before any OAuth flow is initiated.</p>
 *
 * <h2>Why login returns 302</h2>
 * <p>The UI navigates the browser directly to {@code /auth/login}
 * (e.g. {@code window.location.href = '/dashboard/auth/login'}).  This is a same-site
 * top-level navigation so the {@code Set-Cookie} on the 302 response is stored in a
 * first-party context — no cross-origin AJAX fetch or {@code credentials:'include'}
 * required.  The browser then follows the 302 to Entra ID.  When Entra ID redirects back
 * to {@code /auth/callback}, the SESSION cookie is sent because {@code SameSite=None}
 * allows it in all cross-site contexts.</p>
 *
     * <h2>Structured log event codes</h2>
     * <p>Every log statement in this controller uses a structured {@code [EVENT_CODE]} prefix
     * so that GCP Log-Based Metrics can be targeted precisely with a text filter.
     * Event code constants are defined in
     * {@link com.careplus.gatewayservice.constant.CommonConstant} (see the
     * {@code EVT_*} fields) and imported statically here.</p>
 */
@Tag(
    name = "Authentication",
    description = "OAuth 2.0 Authorization Code + PKCE BFF authentication flow. "
        + "Tokens are stored server-side in Redis; the browser receives only an opaque SESSION cookie."
)
@RestController
@RequestMapping(AUTH)
public class AuthController {

    private static final Logger log = LoggerFactory.getLogger(AuthController.class);

    private static final int MAX_EXTERNAL_LOG_VALUE_LENGTH      = 500;
    private static final int MAX_ORIGIN_PARAM_LENGTH            = 2048;
    private static final int MAX_CODE_PARAM_LENGTH              = 2048;
    private static final int MAX_STATE_PARAM_LENGTH             = 512;
    private static final int MAX_ERROR_PARAM_LENGTH             = 256;
    private static final int MAX_ERROR_DESCRIPTION_PARAM_LENGTH = 1024;

    private static final String FORM_PARAM_ERROR_DESCRIPTION = "error_description";
    private static final Pattern ORIGIN_PARAM_PATTERN = Pattern.compile("^https?://[A-Za-z0-9._:\\-/]*$");

    /** Session cookie max-age — driven by ${session.max.inactive.interval} to stay in sync with SessionConfig. */
    @Value("${session.max.inactive.interval:86400}")
    private long sessionMaxInactiveInterval;

    /** Post-login failure redirect path (configured via oauth.post.login.failure.uri.path property). */
    @Value("${oauth.post.login.failure.uri.path:/dealership-access-required}")
    private String postLoginFailureUriPath;

    /**
     * Controls the {@code Secure} attribute on the SESSION cookie.
     * Must be {@code true} in deployed environments; {@code false} only for local plain-HTTP dev.
     */
    @Value("${server.cookie.secure:true}")
    private boolean cookieSecure;

    private final AuthService authService;
    private final OAuthUriResolver oAuthUriResolver;

    public AuthController(AuthService authService, OAuthUriResolver oAuthUriResolver) {
        this.authService = authService;
        this.oAuthUriResolver = oAuthUriResolver;
    }

    // ── Endpoints ─────────────────────────────────────────────────────────────

    /**
     * Initiates the OAuth 2.0 login flow.
     *
     * <p>Resolves and validates OAuth URIs from the request domain, generates PKCE
     * parameters, stores them together with all four OAuth URIs in the Spring
     * {@link WebSession}, sets the SESSION cookie explicitly, and returns
     * {@code 302 Found} redirecting the browser directly to the Entra ID authorization
     * URL.</p>
     *
     * <p>The UI calls this via a top-level browser navigation
     * ({@code window.location.href = '/dashboard/auth/login?origin=' + encodeURIComponent(window.location.origin)}).
     * Passing the explicit {@code origin} parameter is the recommended approach for
     * multi-domain deployments — it eliminates reliance on {@code Referer} headers, which
     * may be stripped by privacy-focused browsers or CDN/proxy policies.</p>
     *
     * <p>The {@code origin} parameter is optional.  When absent, the domain is extracted
     * from {@code Origin}/{@code Referer} request headers with a fallback to the BFF's own
     * base URL (correct in all deployed environments where BFF and UI share a domain).</p>
     *
     * @param clientOrigin optional explicit UI origin (e.g. {@code https://vehiclecare.ford.co.uk}),
     *                     validated against {@code oauth.allowed.domains} before use
     * @return {@code 302 Found} with {@code Location} set to the Entra ID authorization URL,
     *         or {@code 302 Found} to the configured post-login failure URI on error
     */
    @Operation(
        summary = "Initiate OAuth 2.0 login",
        description = "Generates PKCE parameters, builds the Entra ID authorize URL, and issues a "
            + "302 redirect to the authorization server. The SESSION cookie is set on this response "
            + "so the browser carries it through the Entra ID redirect and back to /auth/callback. "
            + "This endpoint is intentionally public (no authentication required) — it initiates the login flow.",
        operationId = "login"
    )
    @ApiResponses({
        @ApiResponse(
            responseCode = "200",
            description = "Redirect is being processed. Clients navigating via window.location.href "
                + "will follow the 302 Location header automatically; this response code applies "
                + "in non-browser contexts where the redirect cannot be followed.",
            content = @Content(
                mediaType = MediaType.APPLICATION_JSON_VALUE,
                schema = @Schema(implementation = APIResponseVoid.class)
            )
        ),
        @ApiResponse(
            responseCode = "302",
            description = "Redirect to the Entra ID authorization endpoint to begin the PKCE flow, "
                + "or to the configured post-login failure URI when origin/domain validation or "
                + "pre-redirect auth setup fails.",
            content = @Content(
                mediaType = MediaType.TEXT_HTML_VALUE,
                schema = @Schema(type = "string", maxLength = 0)
            ),
            headers = {
                @Header(
                    name = "Location",
                    description = "Entra ID authorization URL with PKCE and state parameters, "
                        + "or a relative path to the post-login failure page.",
                    schema = @Schema(type = "string", maxLength = 4096,
                                     pattern = "^(https?://[A-Za-z0-9._:\\-/?=&#%+@!~,;]*|/[A-Za-z0-9/_\\-.?=&#%+@!~,;]*)$")
                ),
                @Header(
                    name = "Set-Cookie",
                    description = "SESSION=<id>; HttpOnly; Secure; SameSite=None; Max-Age=<interval>; Path=/",
                    schema = @Schema(type = "string", maxLength = 4096,
                                     pattern = "^SESSION=[A-Za-z0-9+/=_\\-]{0,256}(; [A-Za-z0-9=;, /:\\-]+)*$")
                )
            }
        ),
        @ApiResponse(
            responseCode = "400",
            description = "Bad Request — a query parameter (e.g. origin) exceeds its declared maxLength constraint.",
                content = @Content(
                        mediaType = MediaType.APPLICATION_JSON_VALUE,
                        schema = @Schema(implementation = APIResponseVoid.class)
                )
        )
    })
    @GetMapping("/login")
    public Mono<Void> login(
            @Parameter(
                description = "Explicit UI origin used to build OAuth redirect URIs. "
                    + "Must match an entry in oauth.allowed.domains. "
                    + "When absent, the origin is derived from the Origin/Referer request header.",
                example = "https://vehiclecare.ford.co.uk",
                schema = @Schema(type = "string", format = "uri", minLength = 1, maxLength = 2048,
                                 pattern = "^https?://[A-Za-z0-9._:\\-/]*$")
            )
            @RequestParam(value = "origin", required = false) String clientOrigin,
            @Parameter(hidden = true) WebSession session,
            @Parameter(hidden = true) ServerWebExchange exchange) {
        // Enforce the documented maxLength/pattern with the canonical JSON 400 body, so
        // OAS-conformance scanners see a proper rejection (a 302 is treated as "accepted").
        if (isInvalidOrigin(clientOrigin)) {
            log.warn("Login request rejected — origin parameter violates the documented maxLength={}/pattern constraints",
                    MAX_ORIGIN_PARAM_LENGTH);
            return ErrorResponseUtil.writeBadRequest(exchange);
        }
        return Mono.fromCallable(() -> oAuthUriResolver.resolveUris(exchange, clientOrigin))
                .flatMap(uris -> authService.initiateOAuthFlow(session, uris))
                .flatMap(authorizeUrl -> {
                    // Set SESSION cookie explicitly before the redirect so the browser
                    // stores it in the /auth/login first-party context and sends it back
                    // on the /auth/callback redirect from Entra ID.
                    exchange.getResponse().addCookie(buildSessionCookie(session.getId(), sessionMaxInactiveInterval));
                    return redirectTo(exchange, authorizeUrl);
                })
                .onErrorResume(InvalidDomainException.class, e -> {
                    log.warn("OAuth login rejected [{}] due to invalid origin/domain: {}",
                            APIErrorCode.VCPGWERR10006.getCode(), e.getMessage(), e);
                    return redirectTo(exchange, postLoginFailureUriPath);
                })
                .onErrorResume(e -> {
                    log.error("OAuth login failed before redirect: type='{}' message='{}'",
                            e.getClass().getSimpleName(), e.getMessage(), e);
                    return redirectTo(exchange, postLoginFailureUriPath);
                });
    }

    /**
     * Returns the authenticated user's identity claims to the dashboard.
     *
     * <p>Called by the UI immediately after it loads following the {@code /auth/callback}
     * redirect.  The SESSION cookie (HttpOnly) is sent automatically by the browser.
     * The raw access token never leaves the server — only decoded claim values are returned.</p>
     *
     * <p>Returns {@code 401 Unauthorized} (with a JSON error body) when no valid BFF
     * session exists, so the UI knows to redirect the user back to {@code /auth/login}.</p>
     *
     * <p>Any unexpected error reading/parsing the stored session (e.g. a malformed access
     * token, a {@code ParseException} from JWT decoding, or a claim type mismatch) is also
     * returned as {@code 401} rather than {@code 500} — a corrupt session is effectively the
     * same as "no active session" from the UI's perspective.</p>
     *
     * @return {@code 200 OK} with {@link UserInfo} body, or {@code 401} if unauthenticated
     */
    @Operation(
        summary = "Get authenticated user info",
        description = "Reads decoded identity claims from the server-side BFF session and returns "
            + "them to the dashboard. The raw access token is never sent to the client. "
            + "Returns 401 when no valid session or session data is unreadable. "
            + "Authentication is enforced via the SESSION cookie (HttpOnly, Secure, SameSite=None) "
            + "backed by Spring Session / Redis. A valid Bearer token in the Authorization header "
            + "is required for the global bearerAuth security scheme.",
        operationId = "me"
    )
    @ApiResponses({
        @ApiResponse(
            responseCode = "200",
            description = "Currently authenticated user's identity claims.",
            content = @Content(
                mediaType = MediaType.APPLICATION_JSON_VALUE,
                schema = @Schema(implementation = UserInfo.class)
            )
        ),
        @ApiResponse(
            responseCode = "401",
            description = "No active session, session expired, or session data is corrupt. "
                + "The UI should redirect the user to /dashboard/auth/login.",
            content = @Content(
                mediaType = MediaType.APPLICATION_JSON_VALUE,
                schema = @Schema(implementation = APIResponseVoid.class)
            )
        ),
        @ApiResponse(
            responseCode = "403",
            description = "Forbidden — user is authenticated but lacks the required application roles.",
            content = @Content(
                mediaType = MediaType.APPLICATION_JSON_VALUE,
                schema = @Schema(implementation = APIResponseVoid.class)
            )
        ),
        @ApiResponse(
            responseCode = "404",
            description = "Not Found",
            content = @Content(
                mediaType = MediaType.APPLICATION_JSON_VALUE,
                schema = @Schema(implementation = APIResponseVoid.class)
            )
        ),
        @ApiResponse(
            responseCode = "406",
            description = "Not Acceptable — the client's Accept header cannot be satisfied.",
            content = @Content(
                mediaType = MediaType.APPLICATION_JSON_VALUE,
                schema = @Schema(implementation = APIResponseVoid.class)
            )
        ),
        @ApiResponse(
            responseCode = "429",
            description = "Too Many Requests — rate limit exceeded.",
            content = @Content(
                mediaType = MediaType.APPLICATION_JSON_VALUE,
                schema = @Schema(implementation = APIResponseVoid.class)
            )
        ),
        @ApiResponse(
            responseCode = "500",
            description = "Internal Server Error",
            content = @Content(
                mediaType = MediaType.APPLICATION_JSON_VALUE,
                schema = @Schema(implementation = APIResponseVoid.class)
            )
        ),
        @ApiResponse(
            responseCode = "default",
            description = "Unexpected Error",
            content = @Content(
                mediaType = MediaType.APPLICATION_JSON_VALUE,
                schema = @Schema(implementation = APIResponseVoid.class)
            )
        )
    })
    @GetMapping("/me")
    public Mono<ResponseEntity<Object>> me(@Parameter(hidden = true) WebSession session,
                                           @Parameter(hidden = true) ServerWebExchange exchange) {
        return authService.getUserInfo(session)
                .map(userInfo -> ResponseEntity.ok((Object) userInfo))
                .onErrorResume(AuthFlowException.OAuthSessionMissingException.class, e -> {
                    // Expected for first-load session checks before login.
                    if (log.isDebugEnabled()) {
                        log.debug("{} [{}] GET /auth/me called without active session",
                                EVT_ME_NO_SESSION, e.getApiErrorCode());
                    }
                    return Mono.just(buildUnauthenticatedResponse());
                })
                .onErrorResume(InvalidStateException.class, e -> {
                        // No active session — expected case when the user has not logged in.
                        // Mark this specific path+exception flow so API END can be downgraded.
                        exchange.getAttributes().put(ATTR_API_END_DEBUG_AUTH_ME_INVALID_STATE, Boolean.TRUE);
                        if (log.isDebugEnabled()) {
                            log.debug("{} [{}] GET /auth/me no active session (InvalidStateException)",
                                    EVT_ME_NO_SESSION, APIErrorCode.VCPGWERR20107.getCode());
                        }
                        return Mono.just(buildUnauthenticatedResponse());
                })
                .onErrorResume(com.careplus.gatewayservice.exception.NoEligibleDealershipException.class,
                        e -> Mono.just(ResponseEntity.status(HttpStatus.FORBIDDEN)
                                .body((Object) java.util.Map.of("errorCode", 1001,
                                        "message", "Dealership Access Required"))))
                .onErrorResume(Exception.class, e -> {
                    // Covers ParseException (malformed JWT), ClassCastException (corrupt claim type),
                    // and any other unexpected error while reading session data.
                    // A corrupt session is treated as "no active session" from the UI's perspective.
                    log.error("{} [{}] GET /auth/me unexpected session-read error: type='{}' message='{}'",
                            EVT_ME_SESSION_READ_ERROR,
                            APIErrorCode.VCPGWERR20107.getCode(),
                            e.getClass().getSimpleName(),
                            e.getMessage(),
                            e);
                    return Mono.just(buildUnauthenticatedResponse());
                });
    }

    /**
     * Handles the OAuth 2.0 callback from Entra ID.
     *
     * <p>This endpoint accepts an HTTP POST with {@code application/x-www-form-urlencoded}
     * body because the authorize URL is built with {@code response_mode=form_post}.  Entra ID
     * POSTs the authorization code (or error) parameters directly to this URL, which prevents
     * the authorization code from appearing in browser history or server-access logs.</p>
     *
     * <p>Post-login and post-failure redirect URIs are read from the Spring Session where
     * they were stored (and validated) during {@code /auth/login}.  If the session does
     * not contain them (e.g. a direct hit to the callback URL), the configured
     * {@code oauth.post.login.failure.uri.path} is used for error cases.</p>
     *
     * <p>Two possible shapes:
     * <ul>
     *   <li><b>Success:</b> {@code code=...&state=...} — validates state, exchanges code
     *       for tokens, stores in session, redirects to the stored post-login URI.</li>
     *   <li><b>Error:</b> {@code error=...&error_description=...&state=...} — Entra ID
     *       rejected the auth request (e.g. {@code invalid_resource}, {@code access_denied}).
     *       Logs the error and redirects to the stored post-login failure URI.</li>
     * </ul>
     * </p>
     *
     * code             authorization code (present on success, absent on error)
     * state            state parameter
     * error            Entra ID error code (present on error, absent on success)
     * error_description human-readable error description from Entra ID
     * @return {@code 302} to stored post-login URI on success,
     *         or stored post-login failure URI / configured failure path on failure
     */
    @Operation(
            summary = "OAuth 2.0 authorization callback from Entra ID (form_post)",
            description = "Receives the authorization code or error from Entra ID via an HTTP POST "
                    + "(response_mode=form_post). On success, validates the PKCE state, exchanges the "
                    + "code for tokens, stores them in the server-side session, and redirects to the "
                    + "post-login URI. On error or state mismatch, the session is invalidated and the "
                    + "browser is redirected to the post-login failure URI. "
                    + "Parameters are delivered as application/x-www-form-urlencoded body, never in "
                    + "the URL query string — this prevents the authorization code from appearing in "
                    + "browser history or server access logs. "
                    + "This endpoint is intentionally public (no authentication required) — it is the OAuth callback target.",

            operationId = "callback"
    )
    @SecurityRequirements  // public endpoint — no authentication required (overrides global bearerAuth)
    @ApiResponses({
            @ApiResponse(
                    responseCode = "200",
                    description = "Redirect is being processed. Clients navigating via window.location.href "
                            + "will follow the 302 Location header automatically; this response code applies "
                            + "in non-browser contexts where the redirect cannot be followed.",
                    content = @Content(
                            mediaType = MediaType.APPLICATION_JSON_VALUE,
                            schema = @Schema(implementation = APIResponseVoid.class)
                    )
            ),
            @ApiResponse(
                    responseCode = "302",
                    description = "Redirect to the stored post-login URI on success, "
                            + "or to the post-login failure URI on any error (Entra error, state mismatch, etc.).",
                    content = @Content(
                            mediaType = MediaType.TEXT_HTML_VALUE,
                            schema = @Schema(type = "string", maxLength = 4096)
                    ),
                    headers = @Header(
                            name = "Location",
                            description = "Absolute URL or relative path of the post-login or post-login-failure page.",
                            schema = @Schema(type = "string", maxLength = 4096,
                                    pattern = "^(https?://[A-Za-z0-9._:\\-/?=&#%+@!~,;]*|/[A-Za-z0-9/_\\-.?=&#%+@!~,;]*)$")
                    )
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "Bad Request — a form parameter (e.g. code, state, error, error_description) "
                            + "exceeds its declared maxLength constraint.",
                    content = @Content(
                            mediaType = MediaType.APPLICATION_JSON_VALUE,
                            schema = @Schema(implementation = APIResponseVoid.class)
                    )
            )
    })
    @PostMapping(value = "/callback", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    @RequestBody(
            description = "OAuth 2.0 authorization response parameters delivered by Entra ID "
                    + "as an application/x-www-form-urlencoded body (response_mode=form_post). "
                    + "On success: 'code' and 'state' are present. "
                    + "On error: 'error' and 'error_description' are present.",
            required = true,
            content = @Content(
                    mediaType = MediaType.APPLICATION_FORM_URLENCODED_VALUE,
                    schema = @Schema(implementation = CallbackFormParams.class)
            )
    )
    public Mono<Void> callback(
            @Parameter(hidden = true) WebSession session,
            @Validated @Parameter(hidden = true) ServerWebExchange exchange) {

        return exchange.getFormData()
                .flatMap(formData -> {
                    String code             = formData.getFirst("code");
                    String state            = formData.getFirst("state");
                    String error            = formData.getFirst("error");
                    // RFC 6749 uses error_description (what Entra ID posts); camelCase is kept
                    // only as a fallback for existing callers/tests.
                    String errorDescription = formData.getFirst(FORM_PARAM_ERROR_DESCRIPTION);
                    if (errorDescription == null) {
                        errorDescription = formData.getFirst("errorDescription");
                    }

                    // Enforce the maxLength constraints declared in CallbackFormParams / OpenAPI spec,
                    // returning the canonical JSON 400 (a 302 is treated as "accepted" by scanners).
                    if ((code             != null && code.length()             > MAX_CODE_PARAM_LENGTH)
                     || (state            != null && state.length()            > MAX_STATE_PARAM_LENGTH)
                     || (error            != null && error.length()            > MAX_ERROR_PARAM_LENGTH)
                     || (errorDescription != null && errorDescription.length() > MAX_ERROR_DESCRIPTION_PARAM_LENGTH)) {
                        log.warn("Callback request rejected — one or more form parameters exceed declared maxLength");
                        return ErrorResponseUtil.writeBadRequest(exchange);
                    }

                    return processCallback(code, state, error, errorDescription, session, exchange);
                })
                .onErrorResume(e -> {
                    log.error("OAuth callback request parsing failed [{}]: type='{}' message='{}'",
                            APIErrorCode.VCPGWERR20110.getCode(), e.getClass().getSimpleName(), e.getMessage(), e);
                    return redirectTo(exchange, postLoginFailureUriPath);
                });
    }

    /**
     * Shared callback logic invoked after reading the request parameters.
     * Extracted so that both parameter sources (form body) are handled identically.
     */
    private Mono<Void> processCallback(
            String code, String state, String error, String errorDescription,
            WebSession session, ServerWebExchange exchange) {
        // Retrieve post-redirect URIs from the single UserSession stored at login time.
        // Reading them BEFORE calling handleCallback() is essential because handleCallback()
        // removes the SESSION_ATTR_LOGIN_FLOW attribute as part of single-use PKCE cleanup.
        UserSession loginFlow = (UserSession) session.getAttributes().get(SESSION_ATTR_LOGIN_FLOW);
        String postLoginRedirectUri = loginFlow != null && loginFlow.getPostLoginRedirectUri() != null
                ? loginFlow.getPostLoginRedirectUri() : "/";
        String postLoginFailureUri  = loginFlow != null && loginFlow.getPostLoginFailureUri() != null
                ? loginFlow.getPostLoginFailureUri() : postLoginFailureUriPath;

        // Entra ID returned an error — log it and redirect to the failure page.
        if (error != null) {
            if (log.isWarnEnabled()) {
                log.warn("Entra ID authorization failed at /auth/callback — error='{}' errorDescription='{}'",
                        sanitizeForLog(error), sanitizeForLog(errorDescription));
            }
            return redirectTo(exchange, postLoginFailureUri);
        }

        // Guard: code must be present for a successful callback.
        if (code == null || state == null) {
            log.warn("OAuth callback rejected [{}] — missing required parameters: code={} state={}",
                    APIErrorCode.VCPGWERR20110.getCode(),
                    code != null ? "<present>" : "<missing>", state != null ? "<present>" : "<missing>");
            return redirectTo(exchange, postLoginFailureUri);
        }

        return authService.handleCallback(code, state, session)
                .then(Mono.defer(() -> redirectTo(exchange, postLoginRedirectUri)))
                .onErrorResume(AuthFlowException.OAuthStateMismatchException.class, e -> {
                    log.warn("OAuth callback rejected — state mismatch [{}]: {}",
                            e.getErrorCode(), e.getMessage(), e);
                    return invalidateSessionAndRedirectToFailure(session, exchange, postLoginFailureUri,
                            "state mismatch");
                })
                .onErrorResume(AuthFlowException.OAuthSessionMissingException.class, e -> {
                    log.warn("OAuth callback rejected — missing or expired login session [{}]: {}",
                            e.getErrorCode(), e.getMessage(), e);
                    return invalidateSessionAndRedirectToFailure(session, exchange, postLoginFailureUri,
                            "missing/expired login session");
                })
                .onErrorResume(AuthFlowException.class, e -> {
                    log.error("OAuth callback token/provider error [{}]: {}",
                            e.getErrorCode(), e.getMessage(), e);
                    return invalidateSessionAndRedirectToFailure(session, exchange, postLoginFailureUri,
                            "token/provider error");
                })
                .onErrorResume(InvalidStateException.class, e -> {
                    log.warn("OAuth callback rejected [{}] — invalid state/session: {}",
                            APIErrorCode.VCPGWERR20103.getCode(), e.getMessage(), e);
                    return invalidateSessionAndRedirectToFailure(session, exchange, postLoginFailureUri,
                            "invalid state/session");
                })
                .onErrorResume(e -> {
                    log.error("OAuth callback unexpected error: type='{}' message='{}'",
                            e.getClass().getSimpleName(), e.getMessage(), e);
                    return invalidateSessionAndRedirectToFailure(session, exchange, postLoginFailureUri,
                            "unexpected callback error");
                });
    }

    private Mono<Void> invalidateSessionAndRedirectToFailure(
            WebSession session,
            ServerWebExchange exchange,
            String postLoginFailureUri,
            String reason
    ) {
        return session.invalidate()
                .onErrorResume(ex -> {
                    log.warn("Failed to invalidate session [{}] after {}: type='{}' message='{}'",
                            session.getId(), reason, ex.getClass().getSimpleName(), ex.getMessage(), ex);
                    return Mono.empty();
                })
                .then(redirectTo(exchange, postLoginFailureUri));
    }

    /**
     * Logs the user out.
     *
     * <p>The SESSION cookie is expired and the Redis session is invalidated
     * <em>unconditionally</em> — even if the Entra ID logout URL cannot be resolved.</p>
     *
     * <p>The {@code post_logout_redirect_uri} is read from the Spring Session where it was
     * stored (and validated) during {@code /auth/login}.  This ensures the browser is sent
     * back to the correct regional domain (e.g. {@code vehiclecare.ford.co.uk}) even though
     * the logout request headers may not carry that information reliably.</p>
     *
     * <p>If the session does not contain the stored URI (e.g. legacy session before this
     * change, or session expiry before logout), the URI is re-resolved from the current
     * request's {@code Origin}/{@code Referer} headers or the optional {@code ?origin=}
     * query parameter, with a safe {@code "/"} fallback.</p>
     *
     * @param clientOrigin optional explicit UI origin (e.g. {@code https://vehiclecare.ford.co.uk}),
     *                     used only when no stored post-logout URI exists in the session
     * @return {@code 302} redirect to the Entra ID logout URL on success,
     *         or {@code 302} to {@code "/"} if domain resolution fails entirely
     */
     @Operation(
         summary = "Log out the authenticated user",
         description = "Expires the SESSION cookie, invalidates the Redis-backed session unconditionally, "
             + "and redirects the browser to the Entra ID end-session endpoint. "
             + "The post-logout redirect URI is resolved from the session (set at login) or, "
             + "for legacy sessions, from the request Origin/Referer headers or the optional "
             + "origin query parameter. "
             + "This endpoint is intentionally public (no authentication required) — users with expired "
             + "sessions must still be able to trigger Entra ID logout.",
         operationId = "logout"
     )
     @ApiResponses({
         @ApiResponse(
             responseCode = "200",
             description = "Redirect is being processed. Clients navigating via window.location.href "
                 + "will follow the 302 Location header automatically; this response code applies "
                 + "in non-browser contexts where the redirect cannot be followed.",
             content = @Content(
                 mediaType = MediaType.APPLICATION_JSON_VALUE,
                 schema = @Schema(implementation = APIResponseVoid.class)
             )
         ),
        @ApiResponse(
            responseCode = "302",
            description = "Session invalidated. Redirect to Entra ID logout endpoint (normal path), "
                + "or to '/' when logout URI resolution fails.",
            content = @Content(
                mediaType = MediaType.TEXT_HTML_VALUE,
                schema = @Schema(type = "string", maxLength = 0)
            ),
             headers = {
                 @Header(
                     name = "Location",
                     description = "Entra ID end-session URL including post_logout_redirect_uri, "
                         + "or '/' when logout URI resolution fails.",
                     schema = @Schema(type = "string", maxLength = 4096,
                                      pattern = "^(https?://[A-Za-z0-9._:\\-/?=&#%+@!~,;]*|/[A-Za-z0-9/_\\-.?=&#%+@!~,;]*)$")
                 ),
                 @Header(
                     name = "Set-Cookie",
                     description = "SESSION=; HttpOnly; Secure; SameSite=None; Max-Age=0; Path=/ (expires cookie)",
                     schema = @Schema(type = "string", maxLength = 512,
                                      pattern = "^SESSION=[A-Za-z0-9+/=_\\-]{0,256}(; [A-Za-z0-9=;, /:\\-]+)*$")
                 )
             }
         ),
         @ApiResponse(
             responseCode = "400",
             description = "Bad Request — a query parameter (e.g. origin) exceeds its declared maxLength constraint.",
                 content = @Content(
                         mediaType = MediaType.APPLICATION_JSON_VALUE,
                         schema = @Schema(implementation = APIResponseVoid.class)
                 )
         )
             // Most failures in this endpoint are handled as redirects (302), but oversized query parameters are rejected with 400.
     })
    @GetMapping("/logout")
    public Mono<Void> logout(
            @Parameter(
                description = "Explicit UI origin used to build the post-logout redirect URI "
                    + "when no stored URI exists in the session. "
                    + "Must match an entry in oauth.allowed.domains.",
                example = "https://vehiclecare.ford.co.uk",
                schema = @Schema(type = "string", format = "uri", minLength = 1, maxLength = 2048,
                                 pattern = "^https?://[A-Za-z0-9._:\\-/]*$")
            )
            @RequestParam(value = "origin", required = false) String clientOrigin,
            @Parameter(hidden = true) WebSession session,
            @Parameter(hidden = true) ServerWebExchange exchange) {
        // Enforce the documented maxLength/pattern with the canonical JSON 400 body, so
        // OAS-conformance scanners see a proper rejection (a 302 is treated as "accepted").
        if (isInvalidOrigin(clientOrigin)) {
            log.warn("Logout request rejected — origin parameter violates the documented maxLength={}/pattern constraints",
                    MAX_ORIGIN_PARAM_LENGTH);
            return ErrorResponseUtil.writeBadRequest(exchange);
        }

        // Always expire the SESSION cookie unconditionally so the browser discards it
        // even if Entra logout URL resolution fails.
        exchange.getResponse().addCookie(buildSessionCookie("", 0L));

        // Prefer the post-logout URI stored in the UserSession at login time — it already has the
        // correct domain resolved and validated.  Fall back to the separately persisted URI (stored
        // during handleCallback after loginFlow is removed), then re-resolution from request headers
        // for legacy sessions that pre-date both attributes.
        UserSession loginFlow = (UserSession) session.getAttributes().get(SESSION_ATTR_LOGIN_FLOW);
        String storedPostLogoutUri = loginFlow != null ? loginFlow.getPostLogoutRedirectUri() : null;

        // Check the separately-persisted URI if loginFlow is gone (removed during handleCallback
        // as part of single-use PKCE cleanup).  Without this fallback, the resolver may return the
        // BFF gateway base URL when the logout request carries no Origin/Referer header.
        if (storedPostLogoutUri == null || storedPostLogoutUri.isBlank()) {
            storedPostLogoutUri = (String) session.getAttributes().get(SESSION_ATTR_POST_LOGOUT_URI);
        }

        // Capture as effectively final so it can be referenced inside lambdas below.
        final String resolvedPostLogoutUri = storedPostLogoutUri;

         if (resolvedPostLogoutUri != null && !resolvedPostLogoutUri.isBlank()) {
             return authService.logout(session, resolvedPostLogoutUri)
                     .onErrorResume(e -> {
                         log.warn("Logout: session invalidation failed (type='{}' error='{}')",
                                 e.getClass().getSimpleName(), e.getMessage(), e);
                         return Mono.just(resolvedPostLogoutUri);
                     })
                    .flatMap(logoutUrl -> redirectTo(exchange, logoutUrl))
                    .onErrorResume(e -> {
                        log.error("Logout flow failed after stored URI resolution: type='{}' message='{}'",
                                e.getClass().getSimpleName(), e.getMessage(), e);
                        return redirectTo(exchange, "/");
                    });
        }

         // Fallback: re-resolve from current request headers / explicit origin param.
         // This path is hit for legacy sessions and direct browser hits to /auth/logout.
         return Mono.fromCallable(() -> oAuthUriResolver.resolveUris(exchange, clientOrigin))
                 .flatMap(uris -> authService.logout(session, uris.postLogoutRedirectUri()))
                 .onErrorResume(e -> {
                     log.warn("Logout: could not resolve Entra logout URI (type='{}' error='{}') — clearing session",
                             e.getClass().getSimpleName(), e.getMessage(), e);
                     return session.invalidate()
                             .onErrorResume(ex -> {
                                 log.warn("Failed to invalidate session [{}] during fallback logout: type='{}' message='{}'",
                                         session.getId(), ex.getClass().getSimpleName(), ex.getMessage(), ex);
                                 return Mono.empty();
                             })
                             .thenReturn("/");
                 })
                .flatMap(logoutUrl -> redirectTo(exchange, logoutUrl))
                .onErrorResume(e -> {
                    log.error("Logout flow failed during fallback URI resolution: type='{}' message='{}'",
                            e.getClass().getSimpleName(), e.getMessage(), e);
                    return redirectTo(exchange, "/");
                });
    }

    // ── Private helpers ───────────────────────────────────────────────────────

    /**
     * Validates {@code origin} against the maxLength/pattern declared in the OpenAPI spec.
     * Done in-handler (not via Jakarta annotations) so the 400 body matches {@link APIResponseVoid}.
     */
    private static boolean isInvalidOrigin(String clientOrigin) {
        if (clientOrigin == null) {
            return false;
        }
        return clientOrigin.isEmpty()
                || clientOrigin.length() > MAX_ORIGIN_PARAM_LENGTH
                || !ORIGIN_PARAM_PATTERN.matcher(clientOrigin).matches();
    }


    /**
     * Builds a {@code 401 Unauthorized} response body using the canonical {@link APIResponseVoid}
     * model.  Extracted to avoid duplicating the same response construction across the two
     * {@code onErrorResume} handlers in {@link #me(WebSession, ServerWebExchange)}.
     *
     * @return a {@code 401} {@link ResponseEntity} carrying an {@link APIResponseVoid} body
     */
    private ResponseEntity<Object> buildUnauthenticatedResponse() {
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .body((Object) ErrorResponseUtil.UNAUTHORIZED_RESPONSE);
    }

    /**
     * Sanitizes and truncates an untrusted external value (e.g., OAuth callback error description,
     * redirect URI from session data) before logging to prevent log forging (CR/LF injection) and
     * log flooding.
     *
     * <p>Replaces all {@code CR}, {@code LF}, and {@code TAB} characters with single spaces,
     * truncates to {@link #MAX_EXTERNAL_LOG_VALUE_LENGTH} characters, and trims leading/trailing
     * whitespace.  This prevents multi-line log injection attacks and ensures oversized external
     * data does not flood structured log storage.</p>
     *
     * @param value the raw, untrusted string from an external source (OAuth provider, session, etc.)
     * @return sanitized and truncated string safe for logging, or {@code "n/a"} if {@code value} is null/blank
     */
    private String sanitizeForLog(String value) {
        if (value == null || value.isBlank()) {
            return "n/a";
        }
        String sanitized = value.replaceAll("[\\r\\n\\t]", " ").trim();
        if (sanitized.length() > MAX_EXTERNAL_LOG_VALUE_LENGTH) {
            return sanitized.substring(0, MAX_EXTERNAL_LOG_VALUE_LENGTH) + "...(truncated)";
        }
        return sanitized;
    }

    /**
     * Builds a {@code SESSION} cookie.
     *
     * <p>{@code SameSite=None} allows the cookie to be sent in all cross-site contexts:
     * the cross-origin fetch from the dashboard to {@code /auth/login}, and the
     * Entra ID top-level redirect back to {@code /auth/callback}. This solves Chrome's
     * Schemeful SameSite enforcement when the dashboard and BFF run on different schemes.</p>
     *
     * <p>{@code Secure=true} is mandatory whenever {@code SameSite=None} is used —
     * browsers silently reject {@code SameSite=None} without {@code Secure}.
     * The flag is configurable via {@code server.cookie.secure} so local development
     * over plain HTTP works without a TLS certificate.</p>
     *
     * @param value         the session ID, or {@code ""} to expire the cookie
     * @param maxAgeSeconds max-age in seconds; {@code 0} expires the cookie immediately
     */
    private ResponseCookie buildSessionCookie(String value, long maxAgeSeconds) {
        return ResponseCookie.from(SESSION_COOKIE, value)
                .httpOnly(true)
                .secure(cookieSecure)   // configurable: true in all deployed envs, false for local HTTP dev
                .sameSite("None")
                .path("/")
                .maxAge(Duration.ofSeconds(maxAgeSeconds))
                .build();
    }

    private Mono<Void> redirectTo(ServerWebExchange exchange, String location) {
        String target = location != null && !location.isBlank() ? location : "/";
        ServerHttpResponse response = exchange.getResponse();

        URI redirectUri;
        try {
            redirectUri = URI.create(target);
        } catch (IllegalArgumentException e) {
            log.warn("Invalid redirect URI '{}' provided; falling back to '/'", sanitizeForLog(target), e);
            redirectUri = URI.create("/");
        }

        response.setStatusCode(HttpStatus.FOUND);
        response.getHeaders().setLocation(redirectUri);
        return response.setComplete()
                .onErrorResume(e -> {
                    log.error("Failed to write redirect response: type='{}' message='{}'",
                            e.getClass().getSimpleName(), e.getMessage(), e);
                    return Mono.empty();
                });
    }

}
