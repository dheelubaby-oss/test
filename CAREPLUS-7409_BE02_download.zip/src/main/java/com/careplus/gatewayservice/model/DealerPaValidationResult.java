package com.careplus.gatewayservice.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.List;

@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DealerPaValidationResult {

    private String primaryPaCode;

    private List<String> allowedPaCodes;

    private String activePaCode;

    private boolean accessAllowed;
}
