package com.careplus.gatewayservice.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Getter;

import java.util.List;

/**
 * User identity claims extracted from the Entra ID access token and returned to
 * the
 * dashboard by {@code GET /dashboard/auth/me}.
 *
 * <p>
 * Claims are sourced from the access token stored in the BFF's server-side
 * session —
 * the raw token is never sent to the browser. Only the claims the UI needs are
 * included; any claim not present in the token is omitted from the response
 * ({@code @JsonInclude(NON_NULL)}).
 * </p>
 *
 * <h2>Supported fordUserType values</h2>
 * <ul>
 * <li>{@code "Dealer"} — dealer portal user</li>
 * <li>{@code "Level0400"} — Ford employee
 * ({@code CommonConstant.EMPLOYEE_USER})</li>
 * <li>{@code "Level0300"} — Ford employee, standard access
 * ({@code CommonConstant.EMPLOYEE_USER_LEVEL0300})</li>
 * <li>{@code "Level0100"} — Ford employee, fleet/basic access
 * ({@code CommonConstant.EMPLOYEE_USER_LEVEL0100})</li>
 * <li>{@code "SharedMBX"} — shared mailbox account
 * ({@code CommonConstant.SHARED_MBX})</li>
 * </ul>
 */
@Getter
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
@Schema(description = "User identity claims extracted from the Entra ID access token.")
public final class UserInfo {
    @JsonProperty("allowedPaCodes")
    private List<String> allowedPaCodes;

    @JsonProperty("activePaCode")
    private String activePaCode;


    // ── Critical ──────────────────────────────────────────────────────────────

    /**
     * Typed DLS entitlement object — contains role assignments, entity name, site
     * codes.
     *
     * <p>
     * Entra ID encodes this claim as a JSON-serialised string in the access token.
     * {@link com.careplus.gatewayservice.serviceimpl.AuthServiceImpl} transparently
     * deserialises it to a {@link DlsEntitlements} POJO so that Jackson serialises
     * it
     * as a JSON object (not a string) — satisfying the OpenAPI schema constraint.
     * </p>
     *
     * <p>
     * For {@code fordUserType=Dealer}, this field is always an empty
     * {@link DlsEntitlements}
     * object (no role assignments) in {@code /dashboard/auth/me} responses to avoid
     * dealer role
     * drift from stale DLS payloads.
     * </p>
     */
    @Schema(description = "DLS entitlement object containing role assignments and entity metadata. Empty object (no role assignments) for fordUserType=Dealer in /dashboard/auth/me responses.", implementation = DlsEntitlements.class)
    @JsonProperty("DLS-Entitlements")
    private DlsEntitlements dlsEntitlements;

    /**
     * User type as issued by Entra ID.
     * Supported values: {@code "Dealer"}, {@code "Level0400"}, {@code "Level0300"},
     * {@code "Level0100"} (Ford employee), or {@code "SharedMBX"}.
     */
    @Schema(description = "User type as issued by Entra ID. Supported values: 'Dealer', 'Level0400', 'Level0300', 'Level0100' (Ford employee), or 'SharedMBX' (shared mailbox).", example = "Dealer", pattern = "^(Dealer|Level0400|Level0300|Level0100|SharedMBX)$", maxLength = 50)
    @JsonProperty("fordUserType")
    private String fordUserType;

    /** Primary Ford site code associated with the user. */
    @Schema(description = "Primary Ford site code associated with the user.", example = "03317", pattern = "^[A-Za-z0-9_\\-]{1,50}$", minLength = 1, maxLength = 50)
    @JsonProperty("fordSiteCode")
    private String fordSiteCode;

    /**
     * ISO country code (e.g. {@code "USA"}). Claim key is {@code "c"} in the token.
     */
    @Schema(description = "ISO country code as carried in the Entra ID token claim 'c' (e.g. 'USA').", example = "USA", pattern = "^[A-Z]{2,10}$", minLength = 2, maxLength = 10)
    @JsonProperty("c")
    private String countryCode;

    /** Token expiry as a Unix epoch second. */
    @Schema(description = "Token expiry as a Unix epoch second.", example = "1800000000", minimum = "0")
    @JsonProperty("exp")
    private Long exp;

    // ── Important ─────────────────────────────────────────────────────────────

    /** User's given (first) name. */
    @Schema(description = "User's given (first) name.", example = "John", pattern = "^[A-Za-z0-9 \\-\\.]{0,200}$", maxLength = 200)
    @JsonProperty("givenName")
    private String givenName;

    /** User's surname (family name). Claim key is {@code "sn"} in the token. */
    @Schema(description = "User's surname (family name). Claim key is 'sn' in the token.", example = "Smith", pattern = "^[A-Za-z0-9 \\-\\.]{0,200}$", maxLength = 200)
    @JsonProperty("sn")
    private String surname;

    /** Subject identifier — unique, stable, opaque user ID issued by Entra ID. */
    @Schema(description = "Subject identifier — unique, stable, opaque user ID issued by Entra ID.", example = "a7b2c3d4-e5f6-7890-abcd-ef1234567890", pattern = "^[A-Za-z0-9@._\\-]{1,256}$", minLength = 1, maxLength = 256)
    @JsonProperty("sub")
    private String sub;

    // ── Optional / Audit ──────────────────────────────────────────────────────

    /** Application roles assigned to the user in Azure. */
    @ArraySchema(maxItems = 50, schema = @Schema(description = "An Azure application role name.", example = "Admin", pattern = "^[A-Za-z0-9_\\-]{1,100}$", maxLength = 100))
    @JsonProperty("roles")
    private List<String> roles;

    /**
     * Secondary site code (may differ from {@code fordSiteCode} in some
     * configurations).
     */
    @Schema(description = "Secondary site code.", example = "03317", pattern = "^[A-Za-z0-9_\\-]{1,50}$", minLength = 1, maxLength = 50)
    @JsonProperty("siteCode")
    private String siteCode;
}
