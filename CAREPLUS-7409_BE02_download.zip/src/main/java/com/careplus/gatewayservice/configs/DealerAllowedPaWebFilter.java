package com.careplus.gatewayservice.configs;

import com.careplus.gatewayservice.serviceimpl.Be02SessionPaAdapter;
import com.careplus.gatewayservice.service.AuthService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Mono;
import java.nio.charset.StandardCharsets;
import java.util.List;

/** BE-02: gate proxied dealer requests using validated, session-owned PA context.
 * AuthService.getUserInfo triggers the initial validation if the context is absent.
 * TODO align path rules and 403 body with ErrorResponseUtil after Index/G-2 is supplied.
 */
@Component
@Order(Ordered.HIGHEST_PRECEDENCE + 10)
@RequiredArgsConstructor
@Slf4j
public class DealerAllowedPaWebFilter implements WebFilter {
    private final AuthService authService;
    private final Be02SessionPaAdapter adapter;
    @Value("${dgl.allowed-pa.enabled:false}")
    private boolean enabled;

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
        if (!enabled || !isProxied(exchange.getRequest().getPath().value())) return chain.filter(exchange);
        if (exchange.getRequest().getCookies().getFirst("SESSION") == null) return chain.filter(exchange);
        return exchange.getSession().flatMap(session -> {
            if (!session.getAttributes().containsKey("oauthSession")) return chain.filter(exchange);
            // Avoid treating a missing or stale context as authorization.
            return authService.getUserInfo(session).flatMap(user -> {
                if (!"Dealer".equalsIgnoreCase(user.getFordUserType())) return chain.filter(exchange);
                Object allowed = session.getAttributes().get(Be02SessionPaAdapter.ALLOWED);
                if (!(allowed instanceof List<?> list) || list.isEmpty()) return deny(exchange);
                return chain.filter(exchange);
            });
        });
    }

    private boolean isProxied(String path) {
        // Confirm the complete proxy path set with GatewayServiceFilter before enabling.
        return !path.contains("/auth/") && !path.endsWith("/auth")
                && !path.contains("/actuator/") && !path.contains("/swagger")
                && !path.contains("/v3/api-docs");
    }

    private Mono<Void> deny(ServerWebExchange exchange) {
        ServerHttpResponse response = exchange.getResponse();
        response.setStatusCode(HttpStatus.FORBIDDEN);
        response.getHeaders().setContentType(MediaType.APPLICATION_JSON);
        byte[] body = "{\"errorCode\":1001,\"message\":\"Dealership access required\"}"
                .getBytes(StandardCharsets.UTF_8);
        return response.writeWith(Mono.just(response.bufferFactory().wrap(body)));
    }
}
