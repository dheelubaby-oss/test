package com.careplus.gatewayservice.configs.auth;

import com.careplus.gatewayservice.constant.APIErrorCode;
import com.careplus.gatewayservice.exception.ForbiddenException;
import com.careplus.gatewayservice.exception.InvalidTokenException;
import com.careplus.gatewayservice.exception.RedisException;
import com.careplus.gatewayservice.model.Dealer;
import com.careplus.gatewayservice.service.CacheService;
import com.careplus.gatewayservice.util.HttpUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nimbusds.jose.jwk.JWKSet;
import com.nimbusds.jose.jwk.RSAKey;
import com.nimbusds.jwt.SignedJWT;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.core.OAuth2Error;
import org.springframework.security.oauth2.core.OAuth2TokenValidator;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtException;
import org.springframework.security.oauth2.jwt.NimbusReactiveJwtDecoder;
import org.springframework.security.oauth2.jwt.ReactiveJwtDecoder;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.security.SecureRandom;
import java.security.interfaces.RSAPublicKey;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import static com.careplus.gatewayservice.constant.CommonConstant.ADMIN;
import static com.careplus.gatewayservice.constant.CommonConstant.ATTRIBUTES_VALUES;
import static com.careplus.gatewayservice.constant.CommonConstant.CARE_PLUS_ENTITY;
import static com.careplus.gatewayservice.constant.CommonConstant.COUNTRY_CODE;
import static com.careplus.gatewayservice.constant.CommonConstant.DATA_ATTRIBUTES;
import static com.careplus.gatewayservice.constant.CommonConstant.DEALER_USER;
import static com.careplus.gatewayservice.constant.CommonConstant.DECODE_TOKEN_ERROR;
import static com.careplus.gatewayservice.constant.CommonConstant.DLS_ENTITLEMENT;
import static com.careplus.gatewayservice.constant.CommonConstant.FORBIDDEN_EXCEPTION;
import static com.careplus.gatewayservice.constant.CommonConstant.INDEX_ZERO;
import static com.careplus.gatewayservice.constant.CommonConstant.INITIAL_BACKOFF_MS;
import static com.careplus.gatewayservice.constant.CommonConstant.JITTER_RATIO;
import static com.careplus.gatewayservice.constant.CommonConstant.JWT_CLAIM_CDSID;
import static com.careplus.gatewayservice.constant.CommonConstant.JWT_KEY_CACHE_HOURS;
import static com.careplus.gatewayservice.constant.CommonConstant.LOGGER_WITH_ERRCODE;
import static com.careplus.gatewayservice.constant.CommonConstant.MAX_BACKOFF_MS;
import static com.careplus.gatewayservice.constant.CommonConstant.MAX_WAIT_ATTEMPTS;
import static com.careplus.gatewayservice.constant.CommonConstant.REDIS_ERROR;
import static com.careplus.gatewayservice.constant.CommonConstant.ROLE_ASSIGNMENT;
import static com.careplus.gatewayservice.constant.CommonConstant.ROLE_NAME;
import static com.careplus.gatewayservice.constant.CommonConstant.SHARED_MBX;
import static com.careplus.gatewayservice.constant.CommonConstant.SITE_CODE;
import static com.careplus.gatewayservice.constant.CommonConstant.SITE_CODE_AND_COUNTRY_CODE_NOT_CONFIGURED;
import static com.careplus.gatewayservice.constant.CommonConstant.SITE_CODE_NOT_CONFIGURED;
import static com.careplus.gatewayservice.constant.CommonConstant.TOKEN_RETRIES;
import static com.careplus.gatewayservice.constant.CommonConstant.USER_TYPE;
import static org.springframework.util.CollectionUtils.isEmpty;


@Slf4j
public class CustomJWTDecoder implements ReactiveJwtDecoder {

    private static final String SIGNED_JWT_REJECTED = "Signed JWT rejected";
    private static final String JWK_KID_NOT_FOUND = "No JWK found for kid";
    private static final OAuth2Error INVALID_TOKEN_ERROR = new OAuth2Error("invalid_token", DECODE_TOKEN_ERROR, null);
    private static final SecureRandom SECURE_RANDOM = new SecureRandom();

    private final String jwkSetURI;
    private final String uiClientId;
    private final String uiClientResource;
    private final String webServiceClientId;
    private final String webServiceClientResource;
    private final ObjectMapper objectMapper;
    private final CacheService cacheService;
    /** Redis key name for the JWK set cache, e.g. {@code "entra_jwt_keys"}. */
    private final String cacheKey;
    /** Derived from {@code cacheKey}: {@code cacheKey + ":lock"}. */
    private final String lockKey;
    /**
     * JWT claim name for client application identity check.
     * Always {@code "azp"} (authorized party) for Entra ID v2.0 tokens.
     */
    private final String clientIdClaim;
    /**
     * Expected JWT issuer URI.  When non-blank the {@code iss} claim in every decoded token
     * must match this value exactly.  Set to
     * {@code https://login.microsoftonline.com/{tenantId}/v2.0} for Entra ID tokens.
     * Leave blank to skip issuer validation (not recommended for production).
     */
    private final String issuerUri;
    /**
     * Composite OAuth2 token validator (e.g. algorithm + default validators).
     * Injected at construction time; set on the Nimbus decoder in {@link #decodeOnce}.
     */
    private final OAuth2TokenValidator<Jwt> jwtTokenValidator;

    /**
     * Allowlist of CDSIDs (lower-cased) permitted to authenticate as {@code SharedMBX} users.
     * Sourced from {@link AuthProviderSettings#allowedCdsIds()} at construction time.
     * Defaults to an empty set when not configured.
     */
    private final Set<String> allowedCdsIds;

    /**
     * Allowlist of ford employee user types (e.g. "level0100", "level0300", "level0400") permitted to authenticate.
     */
    private final Set<String> allowedFordUserEmployeeTypes;

    /**
     * Primary production constructor — settings resolved by
     * {@link com.careplus.gatewayservice.configs.AuthProviderConfig}.
     * Accepts a composite JWT token validator (e.g. algorithm + default validators).
     * Uses a default {@link ObjectMapper}.
     */
    public CustomJWTDecoder(CacheService cacheService, AuthProviderSettings settings,
                            OAuth2TokenValidator<Jwt> jwtTokenValidator) {
        this(
                cacheService,
                settings.uiClientId(),
                settings.uiClientResource(),
                settings.webServiceClientId(),
                settings.webServiceClientResource(),
                settings.jwkSetUri(),
                settings.cacheKey(),
                settings.clientIdClaim(),
                settings.issuerUri(),
                jwtTokenValidator,
                settings.allowedCdsIds(),
                settings.allowedFordUserEmployeeTypes(),
                new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
        );
    }

    /**
     * Backward-compatible production constructor — uses a no-op token validator.
     * Prefer {@link #CustomJWTDecoder(CacheService, AuthProviderSettings, OAuth2TokenValidator)} in production.
     */
    public CustomJWTDecoder(CacheService cacheService, AuthProviderSettings settings) {
        this(cacheService, settings, jwt -> org.springframework.security.oauth2.core.OAuth2TokenValidatorResult.success());
    }

    /**
     * Test-friendly variant — accepts a custom {@link ObjectMapper} alongside an
     * {@link AuthProviderSettings}.  Useful when tests need a spy/mock mapper.
     */
    public CustomJWTDecoder(CacheService cacheService, AuthProviderSettings settings, ObjectMapper objectMapper) {
        this(
                cacheService,
                settings.uiClientId(),
                settings.uiClientResource(),
                settings.webServiceClientId(),
                settings.webServiceClientResource(),
                settings.jwkSetUri(),
                settings.cacheKey(),
                settings.clientIdClaim(),
                settings.issuerUri(),
                jwt -> org.springframework.security.oauth2.core.OAuth2TokenValidatorResult.success(),
                settings.allowedCdsIds(),
                settings.allowedFordUserEmployeeTypes(),
                objectMapper
        );
    }

    /**
     * Full-parameter constructor — all fields explicit.
     * Kept as the single internal delegate for all other constructors, and for tests
     * that need full control over every parameter.
     *
     * @param cacheKey           Redis key for JWK set cache (e.g. {@code "entra_jwt_keys"})
     * @param clientIdClaim      JWT claim name for client identity check (always {@code "azp"} for Entra ID v2.0)
     * @param issuerUri          Expected {@code iss} claim value; blank to skip issuer validation
     * @param jwtTokenValidator  Composite OAuth2 token validator applied after signature verification
     * @param allowedCdsIds      Allowlist of CDSIDs (lower-cased) permitted for {@code SharedMBX} users
     */
    @SuppressWarnings("java:S107")
    public CustomJWTDecoder(
            CacheService cacheService,
            String uiClientId,
            String uiClientResource,
            String webServiceClientId,
            String webServiceClientResource,
            String jwkSetURI,
            String cacheKey,
            String clientIdClaim,
            String issuerUri,
            OAuth2TokenValidator<Jwt> jwtTokenValidator,
            Set<String> allowedCdsIds,
            Set<String> allowedFordUserEmployeeTypes,
            ObjectMapper objectMapper
    ) {
        this.cacheService = cacheService;
        this.uiClientId = uiClientId;
        this.uiClientResource = uiClientResource;
        this.webServiceClientId = webServiceClientId;
        this.webServiceClientResource = webServiceClientResource;
        this.jwkSetURI = jwkSetURI;
        this.cacheKey = cacheKey;
        this.lockKey = cacheKey + ":lock";
        this.clientIdClaim = clientIdClaim;
        this.issuerUri = issuerUri;
        this.jwtTokenValidator = jwtTokenValidator;
        this.allowedCdsIds = allowedCdsIds;
        this.allowedFordUserEmployeeTypes = allowedFordUserEmployeeTypes;
        this.objectMapper = objectMapper;
    }

    /**
     * Convenience constructor — accepts issuer URI, creates a default {@link ObjectMapper}.
     * Uses a no-op token validator. Used by {@link com.careplus.gatewayservice.configs.WebSecurityConfig}.
     *
     * @param issuerUri    expected {@code iss} claim value; blank to skip issuer validation
     * @param objectMapper
     */
    @SuppressWarnings("java:S107")
    public CustomJWTDecoder(
            CacheService cacheService,
            String uiClientId,
            String uiClientResource,
            String webServiceClientId,
            String webServiceClientResource,
            String jwkSetURI,
            String cacheKey,
            String clientIdClaim,
            String issuerUri,
            Set<String> allowedCdsIds,
            Set<String> allowedFordUserEmployeeTypes,
            ObjectMapper objectMapper) {
        this(
                cacheService,
                uiClientId,
                uiClientResource,
                webServiceClientId,
                webServiceClientResource,
                jwkSetURI,
                cacheKey,
                clientIdClaim,
                issuerUri,
                jwt -> org.springframework.security.oauth2.core.OAuth2TokenValidatorResult.success(),
                allowedCdsIds,
                allowedFordUserEmployeeTypes,
                objectMapper
        );
    }

    /**
     * Convenience constructor — creates a default {@link ObjectMapper}. No issuer validation.
     */
    @SuppressWarnings("java:S107")
    public CustomJWTDecoder(
            CacheService cacheService,
            String uiClientId,
            String uiClientResource,
            String webServiceClientId,
            String webServiceClientResource,
            String jwkSetURI,
            String cacheKey,
            String clientIdClaim,
            Set<String> allowedCdsIds,
            Set<String> allowedFordUserEmployeeTypes
    ) {
        this(
                cacheService,
                uiClientId,
                uiClientResource,
                webServiceClientId,
                webServiceClientResource,
                jwkSetURI,
                cacheKey,
                clientIdClaim,
                "",
                jwt -> org.springframework.security.oauth2.core.OAuth2TokenValidatorResult.success(),
                allowedCdsIds,
                allowedFordUserEmployeeTypes,
                new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
        );
    }

    /**
     * Backward-compatible constructor accepting an explicit {@link ObjectMapper}; no issuer validation.
     * Kept for existing test compatibility; prefer the primary constructor in production wiring.
     */
    @SuppressWarnings("java:S107")
    public CustomJWTDecoder(
            CacheService cacheService,
            String uiClientId,
            String uiClientResource,
            String webServiceClientId,
            String webServiceClientResource,
            String jwkSetURI,
            String cacheKey,
            String clientIdClaim,
            Set<String> allowedCdsIds,
            Set<String> allowedFordUserEmployeeTypes,
            ObjectMapper objectMapper
    ) {
        this(
                cacheService,
                uiClientId,
                uiClientResource,
                webServiceClientId,
                webServiceClientResource,
                jwkSetURI,
                cacheKey,
                clientIdClaim,
                "",
                jwt -> org.springframework.security.oauth2.core.OAuth2TokenValidatorResult.success(),
                allowedCdsIds,
                allowedFordUserEmployeeTypes,
                objectMapper
        );
    }

    /**
     * Backward-compatible constructor with explicit issuerUri and {@link ObjectMapper}; no custom validator.
     * Kept for existing test compatibility.
     */
    @SuppressWarnings("java:S107")
    public CustomJWTDecoder(
            CacheService cacheService,
            String uiClientId,
            String uiClientResource,
            String webServiceClientId,
            String webServiceClientResource,
            String jwkSetURI,
            String cacheKey,
            String clientIdClaim,
            String issuerUri,
            ObjectMapper objectMapper
    ) {
        this(
                cacheService,
                uiClientId,
                uiClientResource,
                webServiceClientId,
                webServiceClientResource,
                jwkSetURI,
                cacheKey,
                clientIdClaim,
                issuerUri,
                jwt -> org.springframework.security.oauth2.core.OAuth2TokenValidatorResult.success(),
                Set.of(),Set.of(),
                objectMapper
        );
    }

    @Override
    public Mono<Jwt> decode(String token) {
        return decodeOnce(token)
                .onErrorResume(this::isLikelyKeyRotationIssue, ex -> retryAfterClearingKeyCache(token, ex))
                .onErrorMap(ForbiddenException.class, ex -> {
                    log.error("[{}] {} : {}", APIErrorCode.VCPGWERR30001.getCode(), FORBIDDEN_EXCEPTION, ex.getMessage(), ex);
                    return new OAuth2AuthenticationException(
                            new OAuth2Error(FORBIDDEN_EXCEPTION, DECODE_TOKEN_ERROR, null),
                            ex
                    );
                })
                .onErrorMap(RedisException.class, ex -> {
                    log.error(LOGGER_WITH_ERRCODE, APIErrorCode.VCPGWERR70902.getCode(), REDIS_ERROR, ex);
                    return ex;
                })
                .onErrorMap(ex -> {
                    // Exact-class check (not instanceof): matches only the plain JwtException thrown
                    // by resolvePublicKeyForToken for malformed/non-JWT raw tokens, so that case is
                    // passed through unchanged to BearerTokenSessionFilter's dedicated JwtException
                    // WARN/401 path instead of being re-logged here as an ERROR. Subclasses such as
                    // BadJwtException/JwtValidationException (signature, expiry, custom-validator
                    // failures from NimbusReactiveJwtDecoder) are intentionally NOT matched here and
                    // continue to be wrapped as OAuth2AuthenticationException below.
                    if (ex instanceof OAuth2AuthenticationException || ex.getClass() == JwtException.class) {
                        return ex;
                    }
                    log.error("Token decoding failed [{}]", APIErrorCode.VCPGWERR20901.getCode(), ex);
                    return new OAuth2AuthenticationException(INVALID_TOKEN_ERROR, ex);
                });
    }

    private Mono<Jwt> decodeOnce(String token) {
        return Mono.fromCallable(() -> resolvePublicKeyForToken(token))
                .subscribeOn(Schedulers.boundedElastic())
                .map(publicKey -> {
                    // Explicitly enforce RS256 algorithm (CAREPLUS-5437)
                    NimbusReactiveJwtDecoder decoder = NimbusReactiveJwtDecoder
                            .withPublicKey(publicKey)
                            .build();

                    // Set custom OAuth2 validator for algorithm validation (CAREPLUS-5437)
                    decoder.setJwtValidator(jwtTokenValidator);

                    return decoder;
                })
                .flatMap(decoder -> decoder.decode(token))
                .flatMap(jwt -> validate(jwt).thenReturn(jwt));
    }

    private Mono<Jwt> retryAfterClearingKeyCache(String token, Throwable original) {
        log.warn("JWT decode failed [{}]; clearing JWT key cache [{}] and retrying once. Cause: {}",
                APIErrorCode.VCPGWERR70902.getCode(), cacheKey, original.getMessage(), original);

        return Mono.fromCallable(() -> {
                    cacheService.clearJwtKeys(cacheKey);
                    return true;
                })
                .subscribeOn(Schedulers.boundedElastic())
                .onErrorResume(RedisException.class, e -> {
                    log.warn("Failed to clear JWT key cache in Redis [{}]; retrying decode anyway",
                            APIErrorCode.VCPGWERR70902.getCode(), e);
                    return Mono.empty();
                })
                .then(decodeOnce(token))
                .onErrorMap(ex -> {
                    log.error("Retry token decoding failed [{}]", APIErrorCode.VCPGWERR20904.getCode(), ex);
                    return new OAuth2AuthenticationException(
                            new OAuth2Error("token_decode_retry_failed", DECODE_TOKEN_ERROR, null),
                            ex
                    );
                });
    }

    private boolean isLikelyKeyRotationIssue(Throwable ex) {
        Throwable cause = ex.getCause() != null ? ex.getCause() : ex;
        String msg = cause.getMessage();
        // "Signed JWT rejected" = signature verification failed (wrong key in cache)
        // "No JWK found for kid" = token's kid is absent from cache (Entra ID key rotation)
        return msg != null && (msg.contains(SIGNED_JWT_REJECTED) || msg.contains(JWK_KID_NOT_FOUND));
    }

    /**
     * Returns Mono.empty() when valid; errors when invalid.
     */
    private Mono<Void> validate(Jwt jwt) {
        // Issuer validation — guards against tokens from untrusted IdPs sharing the same audience
        if (issuerUri != null && !issuerUri.isBlank()) {
            String tokenIssuer = jwt.getIssuer() != null ? jwt.getIssuer().toString() : null;
            if (!issuerUri.equals(tokenIssuer)) {
                log.warn("JWT validation failed [{}] — issuer mismatch: expected='{}' got='{}'",
                        APIErrorCode.VCPGWERR20903.getCode(), issuerUri, tokenIssuer);
                return Mono.error(new OAuth2AuthenticationException(INVALID_TOKEN_ERROR));
            }
        }

        if (validateWebServiceToken(jwt)) {
            return Mono.empty();
        }

        // UI token validation touches Redis (blocking) -> run on boundedElastic
        return Mono.fromCallable(() -> validateUiClientToken(jwt))
                .subscribeOn(Schedulers.boundedElastic())
                .flatMap(valid -> valid
                        ? Mono.empty()
                        : Mono.error(new OAuth2AuthenticationException(INVALID_TOKEN_ERROR)));
    }

    private boolean validateWebServiceToken(Jwt jwt) {
        Object clientIdValue = jwt.getClaim(clientIdClaim);
        boolean clientMatch = clientIdValue != null && clientIdValue.toString().equals(webServiceClientId);
        boolean audienceMatch = jwt.getAudience().contains(webServiceClientResource);
        return clientMatch && audienceMatch;
    }

    private boolean validateUiClientToken(Jwt jwt) throws ForbiddenException, RedisException {
        Object clientIdValue = jwt.getClaim(clientIdClaim);
        boolean clientMatch = clientIdValue != null && clientIdValue.toString().equals(uiClientId);
        boolean audienceMatch = jwt.getAudience().contains(uiClientResource);
        if (!clientMatch || !audienceMatch) {
            log.warn("JWT UI-client validation failed — {}={} clientMatch={}, audienceMatch={}",
                    clientIdClaim, clientIdValue, clientMatch, audienceMatch);
            return false;
        }
        return hasValidUserType(jwt);
    }

    private boolean hasValidUserType(Jwt jwt) throws ForbiddenException, RedisException {
        String userType = jwt.getClaim(USER_TYPE);
        String cdsid = jwt.getClaim(JWT_CLAIM_CDSID);

        if (userType == null || userType.isBlank()) {
            log.warn("JWT validation failed — '{}' claim is absent or blank. "
                    + "For Entra ID tokens this claim must be added via Azure Portal "
                    + "→ App registrations → Token configuration → Add optional/custom claim.",
                    USER_TYPE);
            return false;
        }

        if (DEALER_USER.equals(userType)) {
            return isDealerWithValidSiteCode(jwt);
        }

        //allowedFordUserEmployeeTypes is expected to contain ford employee user types such as "level0100", "level0300", "level0400"
        if (allowedFordUserEmployeeTypes.contains(userType.toLowerCase(Locale.ROOT))) {
            return hasValidDlsEntitlement(jwt);
        }


        // Supported fordUserType values: "SharedMBX" for generic mail ".
        if (SHARED_MBX.equalsIgnoreCase(userType) && StringUtils.isNotBlank(cdsid)) {
            return allowedCdsIds.contains(cdsid.toLowerCase(Locale.ROOT)) && hasValidDlsEntitlement(jwt);
        }

        log.warn("JWT validation failed — unrecognised fordUserType='{}' "
                + "(expected '{}', '{}', or '{}')",
                userType, DEALER_USER,allowedFordUserEmployeeTypes, SHARED_MBX);
        return false;
    }

    private boolean isDealerWithValidSiteCode(Jwt jwt) {
        // Authentication validates identity claims; onboarding is performed against ALL
        // Partner IAM PA codes after authentication, not solely the JWT primary PA.
        Object primary = jwt.getClaim(SITE_CODE);
        String country = jwt.getClaimAsString(COUNTRY_CODE);
        return primary instanceof String code && !code.isBlank()
                && country != null && !country.isBlank();
    }

    private boolean isValidFordSiteCodeAndCountryCode(String fordSiteCode, String countryCode) throws ForbiddenException, RedisException {
        String dealerJson = cacheService.getDealer(fordSiteCode);

        if (StringUtils.isBlank(dealerJson)) {
            throw new ForbiddenException(SITE_CODE_NOT_CONFIGURED.concat(fordSiteCode));
        }

        try {
            Dealer dealer = objectMapper.readValue(dealerJson, Dealer.class);
            if (dealer.getDealerCode().equals(fordSiteCode) && dealer.getCountryCode().equals(countryCode)) {
                return true;
            } else {
                throw new ForbiddenException(String.format(SITE_CODE_AND_COUNTRY_CODE_NOT_CONFIGURED, fordSiteCode, countryCode));
            }
        } catch (JsonProcessingException e) {
            throw new ForbiddenException(SITE_CODE_NOT_CONFIGURED.concat(fordSiteCode));
        }
    }

    private boolean isFordSiteCodeValid(Object fordSiteCode) throws RedisException {
        if (!(fordSiteCode instanceof String code) || code.isEmpty()) {
            return false;
        }

        String dealerJson = cacheService.getDealer(code);
        if (dealerJson == null) {
            return false;
        }

        try {
            Dealer dealer = objectMapper.readValue(dealerJson, Dealer.class);
            return dealer.getDealerCode().equals(code);
        } catch (JsonProcessingException e) {
            return false;
        }
    }

    private boolean hasValidDlsEntitlement(Jwt jwt) throws ForbiddenException, RedisException {
        try {
            Object dlsEntitlementClaim = jwt.getClaim(DLS_ENTITLEMENT);
            if (dlsEntitlementClaim == null) {
                log.warn("JWT validation failed — '{}' claim is absent. "
                        + "For Entra ID tokens this claim must be added via Azure Portal "
                        + "→ App registrations → Token configuration → Add optional/custom claim.",
                        DLS_ENTITLEMENT);
                return false;
            }
            String dlsEntitlementStr = dlsEntitlementClaim.toString();
            String userType = jwt.getClaim(USER_TYPE);

            DLSEntitlement dlsEntitlement = objectMapper.readValue(dlsEntitlementStr, DLSEntitlement.class);
            JsonNode roleAssignmentNode = objectMapper.readTree(dlsEntitlementStr).path(ROLE_ASSIGNMENT);
            if ((allowedFordUserEmployeeTypes.contains(userType.toLowerCase(Locale.ROOT))
                    || SHARED_MBX.equalsIgnoreCase(userType))
                    && isEmpty(dlsEntitlement.getRoleAssignments())) {
                throw new ForbiddenException("DLS Entitlement is empty or missing for employee user");
            }
            return !isEmpty(dlsEntitlement.getRoleAssignments()) &&
                    CARE_PLUS_ENTITY.equals(dlsEntitlement.getRoleAssignments().get(0).getEntityName())
                    && hasValidFordSiteCode(roleAssignmentNode);
        } catch (JsonProcessingException e) {
            log.error("Error decoding token [{}]", APIErrorCode.VCPGWERR80902.getCode(), e);
            return false;
        }
    }

    private boolean hasValidFordSiteCode(JsonNode roleAssignmentNode) throws ForbiddenException, RedisException {
        String roleName = roleAssignmentNode.get(INDEX_ZERO).path(ROLE_NAME).asText();

        if (roleName.contains(ADMIN)) {
            return true;
        }

        JsonNode dataAttributesNode = roleAssignmentNode.get(INDEX_ZERO).path(DATA_ATTRIBUTES);
        if (dataAttributesNode.isArray() && !dataAttributesNode.isEmpty()) {
            JsonNode siteCodeNode = dataAttributesNode.get(INDEX_ZERO).path(ATTRIBUTES_VALUES);
            for (JsonNode fordSiteCode : siteCodeNode) {
                if (isFordSiteCodeValid(fordSiteCode.asText())) {
                    return true;
                }
            }
            throw new ForbiddenException(SITE_CODE_NOT_CONFIGURED.concat(siteCodeNode.asText()));
        }

        return false;
    }

    /**
     * Resolve the RSA public key that signed the given raw JWT string by matching
     * the token's {@code kid} header against the cached (or freshly fetched) JWK set.
     *
     * <p>Entra ID publishes 5-6 rotated keys — kid-based matching is required to select
     * the correct key and avoid rejecting valid tokens during key rotations.</p>
     */
    private RSAPublicKey resolvePublicKeyForToken(String rawToken) {
        // Isolated from the JWK-resolution try/catch below: a malformed/non-JWT raw token
        // (e.g. missing segment delimiters) is bad client input, not a system fault. Throwing
        // JwtException here routes it through BearerTokenSessionFilter's existing WARN/401
        // JwtException path instead of the generic-Exception ERROR path, so this case no longer
        // inflates VCPGWERR20106 ERROR-log volume/alerting.
        String kid;
        try {
            kid = SignedJWT.parse(rawToken).getHeader().getKeyID();
        } catch (java.text.ParseException e) {
            String errorMessage = "Failed to resolve public key: " + e.getMessage();
            log.warn(LOGGER_WITH_ERRCODE, APIErrorCode.VCPGWERR80902.getCode(), errorMessage, e);
            throw new JwtException(errorMessage, e);
        }

        try {
            String jwkSetJson = getCachedOrFetchJwtKeys();
            JWKSet jwkSet = JWKSet.parse(jwkSetJson);

            RSAKey matchedKey = jwkSet.getKeys().stream()
                    .filter(k -> k instanceof RSAKey && kid != null && kid.equals(k.getKeyID()))
                    .map(RSAKey.class::cast)
                    .findFirst()
                    .orElseThrow(() -> new InvalidTokenException(APIErrorCode.VCPGWERR20901, "No JWK found for kid: " + kid));

            return matchedKey.toRSAPublicKey();
        } catch (InvalidTokenException e) {
            throw new OAuth2AuthenticationException(new OAuth2Error(REDIS_ERROR, e.getMessage(), null), e);
        } catch (InterruptedException e) {
            // Preserve interrupt status so upstream callers can observe cancellation semantics.
            Thread.currentThread().interrupt();
            String errorMessage = "Interrupted while resolving public key";
            log.error(LOGGER_WITH_ERRCODE, APIErrorCode.VCPGWERR20904.getCode(), errorMessage, e);
            throw new OAuth2AuthenticationException(new OAuth2Error(REDIS_ERROR, errorMessage, null), e);
        } catch (Exception e) {
            // Covers JWKSet.parse(jwkSetJson) failures (e.g. corrupt Redis/provider JWK data) —
            // a genuine system/config fault, kept on the ERROR path for operational alerting.
            String errorMessage = "Failed to resolve public key: " + e.getMessage();
            log.error(LOGGER_WITH_ERRCODE, APIErrorCode.VCPGWERR80902.getCode(), errorMessage, e);
            throw new OAuth2AuthenticationException(new OAuth2Error(REDIS_ERROR, errorMessage, null), e);
        }
    }

    /**
     * Fetch JWK keys from the configured endpoint with retry logic.
     */
    private String fetchJwtKeysWithRetry() throws InvalidTokenException {
        for (int attempt = 0; attempt <= TOKEN_RETRIES; attempt++) {
            try {
                return HttpUtil.getWithTimeout(jwkSetURI);
            } catch (Exception e) {
                log.warn("Attempt {} to fetch JWT keys failed [{}]: {}",
                        attempt + 1, APIErrorCode.VCPGWERR70901.getCode(), e.getMessage());
                if (attempt == TOKEN_RETRIES) {
                    throw new IllegalStateException("Failed to fetch JWT keys after all retry attempts", e);
                }
            }
        }
        throw new InvalidTokenException(APIErrorCode.VCPGWERR20904, "Failed to fetch JWT keys after all retry attempts");
    }

    /**
     * Retrieve JWK keys from cache, or fetch from the JWK set URI and cache them.
     */
    private String getCachedOrFetchJwtKeys() throws RedisException, InvalidTokenException, InterruptedException {
        String keys = cacheService.getJwtKeys(cacheKey);
        if (keys != null) {
            return keys;
        }

        String token = cacheService.tryAcquireJwtKeysRefreshLock(30, TimeUnit.SECONDS, lockKey);
        if (token != null) {
            try {
                // Double-check after acquiring the lock
                keys = cacheService.getJwtKeys(cacheKey);
                if (keys != null) {
                    return keys;
                }

                String fetched = fetchJwtKeysWithRetry();
                cacheService.setJwtKeys(fetched, JWT_KEY_CACHE_HOURS, TimeUnit.HOURS, cacheKey);
                return fetched;
            } finally {
                cacheService.releaseJwtKeysRefreshLock(token, lockKey);
            }
        }

        return waitForKeysOrFetchFallback();
    }

    private String waitForKeysOrFetchFallback() throws RedisException, InvalidTokenException, InterruptedException {
        long backoffMs = INITIAL_BACKOFF_MS;

        for (int attempt = 1; attempt <= MAX_WAIT_ATTEMPTS; attempt++) {
            String cached = cacheService.getJwtKeys(cacheKey);
            if (cached != null) {
                return cached;
            }

            sleepWithJitter(backoffMs);
            backoffMs = Math.min(backoffMs * 2, MAX_BACKOFF_MS);
        }

        return fetchJwtKeysWithRetry();
    }

    private void sleepWithJitter(long baseMs) throws InterruptedException {
        if (baseMs <= 0) {
            return;
        }

        long jitter = Math.max(1L, Math.round(baseMs * JITTER_RATIO));
        long minMs = Math.max(0L, baseMs - jitter);
        long maxMs = baseMs + jitter;
        int range = Math.toIntExact(maxMs - minMs + 1);

        long delayMs = minMs + SECURE_RANDOM.nextInt(range);
        TimeUnit.MILLISECONDS.sleep(delayMs);
    }

}
