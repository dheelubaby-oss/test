package com.careplus.gatewayservice.serviceimpl;

import com.careplus.gatewayservice.constant.APIErrorCode;
import com.careplus.gatewayservice.exception.AuthFlowException;
import com.careplus.gatewayservice.exception.InvalidStateException;
import com.careplus.gatewayservice.model.DlsEntitlements;
import com.careplus.gatewayservice.model.OAuthSession;
import com.careplus.gatewayservice.model.OAuthUris;
import com.careplus.gatewayservice.model.UserInfo;
import com.careplus.gatewayservice.model.UserSession;
import com.careplus.gatewayservice.service.AuthService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nimbusds.jwt.SignedJWT;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import org.springframework.web.server.WebSession;
import reactor.core.publisher.Mono;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.time.Duration;
import java.time.Instant;
import java.util.Base64;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.careplus.gatewayservice.constant.CommonConstant.DEALER_USER;
import static com.careplus.gatewayservice.constant.CommonConstant.DLS_ENTITLEMENT;
import static com.careplus.gatewayservice.constant.CommonConstant.LOGGER_WITH_ERRCODE;
import static com.careplus.gatewayservice.constant.CommonConstant.USER_TYPE;

/**
 * Reactive implementation of the BFF OAuth 2.0 Authorization Code + PKCE flow.
 *
 * <p>PKCE {@code code_verifier}, {@code state}, and all four OAuth redirect URIs are
 * bundled into a single {@link UserSession} and stored as one Spring Session attribute
 * ({@link #SESSION_ATTR_LOGIN_FLOW}) at {@code /auth/login} time.  Tokens are stored
 * separately via {@link #SESSION_ATTR_OAUTH_SESSION} after the callback.  The browser
 * only holds the opaque SESSION cookie; tokens and redirect URIs never reach the client.</p>
 *
 * <p>Using Spring Session (backed by Redis via {@code @EnableRedisWebSession}) means
 * no separate {@code pkce:{state}} Redis keys are needed — the session IS the PKCE
 * and URI holder.</p>
 */
@Service
public class AuthServiceImpl implements AuthService {

    private static final Logger log = LoggerFactory.getLogger(AuthServiceImpl.class);

    /** OAuth grant/field constant used by refresh-token requests and token responses. */
    private static final String REFRESH_TOKEN = "refresh_token";

    /** PKCE verifier byte length — 96 bytes → 128-char Base64URL string (RFC 7636 §4.1). */
    private static final int PKCE_VERIFIER_BYTES = 96;

    /**
     * Reusable Base64URL encoder (without padding) for PKCE operations.
     * Extracting this as a constant avoids creating a new encoder instance on every
     * {@code generateCodeVerifier()} and {@code generateCodeChallenge()} call.
     */
    private static final Base64.Encoder URL_ENCODER = Base64.getUrlEncoder().withoutPadding();

    /** Reusable cryptographically strong random source for PKCE verifier generation. */
    private static final SecureRandom SECURE_RANDOM = new SecureRandom();

    /** Max length for token endpoint error body logs to avoid oversized entries. */
    private static final int MAX_ERROR_BODY_LOG_LENGTH = 2000;

    /** Regex used to extract Microsoft AADSTS error codes from token endpoint responses. */
    private static final Pattern AADSTS_ERROR_CODE_PATTERN = Pattern.compile("(AADSTS\\d+)");

    /** Reusable map type reference for WebClient token endpoint responses. */
    private static final ParameterizedTypeReference<Map<String, Object>> TOKEN_RESPONSE_TYPE =
            new ParameterizedTypeReference<>() {
            };

    /**
     * Spring Session attribute key for the bundled PKCE + OAuth redirect URI state.
     * All six login-flow fields are stored as a single {@link UserSession} object so that
     * cleanup is one {@code remove()} call rather than six.
     */
    public static final String SESSION_ATTR_LOGIN_FLOW = "loginFlow";

    // ── Legacy individual-attribute constants (kept for test compatibility) ─────

    /** Spring Session attribute key for the stored {@link OAuthSession} (tokens + expiry). */
    public static final String SESSION_ATTR_OAUTH_SESSION = "oauthSession";

    /**
     * Spring Session attribute key for the post-logout redirect URI.
     *
     * <p>This is stored separately from {@link #SESSION_ATTR_LOGIN_FLOW} because
     * {@code loginFlow} is removed (single-use PKCE cleanup) at the end of
     * {@link #handleCallback}.  The post-logout URI must survive that removal so
     * that {@code /auth/logout} can still redirect to the correct dashboard domain
     * rather than falling back to the BFF gateway base URL.</p>
     */
    public static final String SESSION_ATTR_POST_LOGOUT_URI = "postLogoutUri";

    /** Entra ID authorization endpoint. */
    @Value("${entra.authorize.endpoint:}")
    private String authorizeEndpoint;

    /** Entra ID token endpoint. */
    @Value("${entra.token.endpoint:}")
    private String tokenEndpoint;

    /** Entra ID logout endpoint. */
    @Value("${entra.logout.endpoint:}")
    private String logoutEndpoint;

    /** OAuth2 scopes to request. */
    @Value("${oauth.scopes:}")
    private String scopes;

    /** OAuth2 client ID for the UI app registration. */
    @Value("${ui_client_id:}")
    private String clientId;

    /**
     * OAuth2 client secret for the UI app registration.
     * The Consumer app is a confidential client (it has a client secret registered in
     * Azure Portal). Entra ID's token endpoint requires {@code client_secret} for all
     * confidential client token requests (authorization_code and refresh_token grants).
     * In deployed environments this is injected from GCP Secret Manager.
     */
    @Value("${ui_client_secret:}")
    private String clientSecret;

    private final WebClient webClient;
    private final com.careplus.gatewayservice.service.DealerPaValidationService dealerPaValidationService;
    private final Be02SessionPaAdapter paSessionAdapter;

    /**
     * Shared {@link ObjectMapper} instance used exclusively to deserialize JWT claims whose
     * values Entra ID encodes as a JSON string rather than a nested JSON object
     * (e.g. {@code DLS-Entitlements}).  {@code ObjectMapper} is thread-safe for concurrent
     * read/deserialization operations.
     */
    private static final ObjectMapper CLAIM_OBJECT_MAPPER = new ObjectMapper();

    public AuthServiceImpl(WebClient.Builder webClientBuilder,
            com.careplus.gatewayservice.service.DealerPaValidationService dealerPaValidationService,
            Be02SessionPaAdapter paSessionAdapter) {
        this.webClient = webClientBuilder.build();
        this.dealerPaValidationService = dealerPaValidationService;
        this.paSessionAdapter = paSessionAdapter;
    }

    // ── Public API ────────────────────────────────────────────────────────────

    /**
     * {@inheritDoc}
     *
     * <p>Bundles all six PKCE and OAuth URI values into a single {@link UserSession}
     * and stores it under {@link #SESSION_ATTR_LOGIN_FLOW}.  Single-attribute storage
     * ensures cleanup is one {@code remove()} call rather than six, eliminating the
     * risk of partial cleanup.</p>
     */
    @Override
    public Mono<String> initiateOAuthFlow(WebSession session, OAuthUris uris) {
        return Mono.fromCallable(() -> {
            String codeVerifier  = generateCodeVerifier();
            String codeChallenge = generateCodeChallenge(codeVerifier);
            String state         = UUID.randomUUID().toString();

            // Bundle all six login-flow values into one session attribute.
            // Storing all four URIs at login time ensures the correct domain is used
            // throughout the entire flow (callback + logout) without re-resolving from
            // request headers, which may be absent or stripped in some environments.
            UserSession loginFlow = new UserSession(
                    codeVerifier,
                    state,
                    uris.redirectUri(),
                    uris.postLoginRedirectUri(),
                    uris.postLoginFailureUri(),
                    uris.postLogoutRedirectUri()
            );
            session.getAttributes().put(SESSION_ATTR_LOGIN_FLOW, loginFlow);

            log.info("Stored pending OAuth login flow for session [{}...] redirectUri='{}' postLoginRedirect='{}'",
                    abbreviateSessionId(session.getId()),
                    sanitizeLogValue(uris.redirectUri()),
                    sanitizeLogValue(uris.postLoginRedirectUri()));

            return new PendingOAuthFlow(
                    buildAuthorizeUrl(state, codeChallenge, uris.redirectUri())
            );
        }).flatMap(flow -> session.save().thenReturn(flow.authorizeUrl()));
    }

    /**
     * {@inheritDoc}
     *
     * <p>Reads the {@link UserSession} from {@link #SESSION_ATTR_LOGIN_FLOW}, validates
     * the {@code state} parameter, exchanges the authorization code for tokens, stores the
     * resulting {@link OAuthSession} in the session, updates the session TTL to match the
     * token expiry, and removes the single-use {@link UserSession} attribute in one call.</p>
     */
    @Override
    public Mono<Void> handleCallback(String authCode, String state, WebSession session) {
        return validateLoginFlow(state, session)
                .flatMap(arr -> exchangeCodeForTokens(authCode, arr[0], arr[1]))
                .flatMap(tokenResponse -> storeTokensInSession(tokenResponse, session));
    }

    /**
     * Validates the {@link UserSession} bundled PKCE + OAuth URI state stored in the session.
     *
     * <p>Checks that the {@code state} parameter matches the expected value, and that both
     * {@code code_verifier} and {@code redirect_uri} are present. Returns a two-element array
     * {@code [codeVerifier, redirectUri]} for use in the token exchange step.</p>
     *
     * @param state   the OAuth {@code state} parameter received from the authorization server
     * @param session the current {@link WebSession} holding the login-flow attribute
     * @return a {@link Mono} emitting {@code [codeVerifier, redirectUri]}, or an error
     *         {@link Mono} wrapping an {@link AuthFlowException.OAuthSessionMissingException} on validation failure
     */
    private Mono<String[]> validateLoginFlow(String state, WebSession session) {
        return Mono.fromCallable(() -> {
            UserSession loginFlow = (UserSession) session.getAttributes().get(SESSION_ATTR_LOGIN_FLOW);

            String expectedState = loginFlow != null ? loginFlow.getState()        : null;
            String codeVerifier  = loginFlow != null ? loginFlow.getCodeVerifier() : null;
            String redirectUri   = loginFlow != null ? loginFlow.getRedirectUri()  : null;

            if (expectedState == null || !expectedState.equals(state)) {
                log.warn("OAuth callback state validation failed [{}] expectedStatePresent={} actualStatePresent={}",
                        APIErrorCode.VCPGWERR20102.getCode(), expectedState != null, state != null);
                throw new AuthFlowException.OAuthStateMismatchException(
                        "OAuth state mismatch — possible CSRF or replay attack");
            }
            if (codeVerifier == null) {
                throw new AuthFlowException.OAuthSessionMissingException(
                        "PKCE code_verifier not found in session — session may have expired");
            }
            if (redirectUri == null) {
                throw new AuthFlowException.OAuthSessionMissingException(
                        "oauth_redirect_uri not found in session — session may have expired");
            }
            return new String[]{codeVerifier, redirectUri};
        });
    }

    /**
     * Stores the OAuth tokens in the Spring Session and performs post-callback cleanup.
     *
     * <p>Specifically:
     * <ol>
     *   <li>Builds an {@link OAuthSession} from the token response and stores it.</li>
     *   <li>Updates the session TTL to match the token expiry.</li>
     *   <li>Persists the post-logout URI separately so it survives login-flow removal.</li>
     *   <li>Removes the single-use login-flow attribute (PKCE state + redirect URIs).</li>
     * </ol>
     * </p>
     *
     * @param tokenResponse the raw token map from the Entra ID token endpoint
     * @param session       the current {@link WebSession} to update
     * @return an empty {@link Mono} signalling completion
     */
    private Mono<Void> storeTokensInSession(Map<String, Object> tokenResponse, WebSession session) {
        OAuthSession oauthSession = buildSession(tokenResponse);
        // Store tokens in Spring Session.
        session.getAttributes().put(SESSION_ATTR_OAUTH_SESSION, oauthSession);
        // Update session TTL to match the actual token expiry — ties the Redis session
        // lifetime to the OAuth token so sessions do not outlive their tokens.
        if (oauthSession.getExpiresAt() != null) {
            Duration tokenLifetime = Duration.between(Instant.now(), oauthSession.getExpiresAt());
            if (!tokenLifetime.isNegative()) {
                session.setMaxIdleTime(tokenLifetime);
            }
        }
        // Persist the post-logout URI BEFORE removing loginFlow so that /auth/logout
        // can redirect to the correct dashboard domain even after loginFlow is gone.
        // Without this, the fallback resolver uses the request's Origin/Referer which
        // may be absent on the logout request, causing a redirect to the BFF base URL ("/").
        UserSession loginFlowForLogout = (UserSession) session.getAttributes().get(SESSION_ATTR_LOGIN_FLOW);
        if (loginFlowForLogout != null && loginFlowForLogout.getPostLogoutRedirectUri() != null
                && !loginFlowForLogout.getPostLogoutRedirectUri().isBlank()) {
            session.getAttributes().put(SESSION_ATTR_POST_LOGOUT_URI,
                    loginFlowForLogout.getPostLogoutRedirectUri());
        }
        // Remove the single-use login-flow attribute (PKCE state + redirect URIs).
        // One remove instead of six separate attribute removals.
        session.getAttributes().remove(SESSION_ATTR_LOGIN_FLOW);
        if (log.isInfoEnabled()) {
            log.info("OAuth callback successful; tokens stored in Spring Session [{}...]",
                    abbreviateSessionId(session.getId()));
        }
        return session.save()
                .doOnError(ex -> log.error("OAuth session persistence failed [{}]: {}",
                        APIErrorCode.VCPGWERR80102.getCode(), ex.getMessage(), ex));
    }

    /**
     * {@inheritDoc}
     *
     * <p>Invalidates the Spring Session (Spring Session removes it from Redis) and
     * returns the Entra ID logout URL containing the provided
     * {@code post_logout_redirect_uri}.  The caller should also expire the SESSION cookie
     * in the browser response.</p>
     */
    @Override
    public Mono<String> logout(WebSession session, String postLogoutRedirectUri) {
        return session.invalidate()
                .doOnSuccess(v -> {
                    if (log.isInfoEnabled()) {
                        log.info("Spring Session [{}...] invalidated on logout",
                                abbreviateSessionId(session.getId()));
                    }
                })
                .onErrorResume(e -> {
                    if (log.isWarnEnabled()) {
                        log.warn("Failed to invalidate session [{}] [{}...] during logout: {}",
                                APIErrorCode.VCPGWERR70802.getCode(),
                                abbreviateSessionId(session.getId()),
                                e.getMessage());
                    }
                    return Mono.empty();
                })
                .thenReturn(buildLogoutUrl(postLogoutRedirectUri));
    }

    // ── Private helpers ───────────────────────────────────────────────────────

    /**
     * Generates a cryptographically random PKCE {@code code_verifier}.
     * 96 random bytes encoded as Base64URL without padding → 128-character string.
     */
    private String generateCodeVerifier() {
        byte[] randomBytes = new byte[PKCE_VERIFIER_BYTES];
        SECURE_RANDOM.nextBytes(randomBytes);
        return URL_ENCODER.encodeToString(randomBytes);
    }

    /**
     * Derives the PKCE {@code code_challenge} from the verifier using S256 method.
     * {@code BASE64URL(SHA-256(ASCII(code_verifier)))} as specified by RFC 7636 §4.2.
     */
    private String generateCodeChallenge(String codeVerifier) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(codeVerifier.getBytes(StandardCharsets.US_ASCII));
            return URL_ENCODER.encodeToString(hash);
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 algorithm unavailable", e);
        }
    }

    private String buildAuthorizeUrl(String state, String codeChallenge, String redirectUri) {
        return authorizeEndpoint
                + "?response_type=code"
                + "&response_mode=form_post"
                + "&client_id="             + encode(clientId)
                + "&redirect_uri="          + encode(redirectUri)
                + "&scope="                 + encode(scopes)
                + "&state="                 + encode(state)
                + "&code_challenge="        + encode(codeChallenge)
                + "&code_challenge_method=S256";
    }

    private String buildLogoutUrl(String postLogoutRedirectUri) {
        return logoutEndpoint
                + "?post_logout_redirect_uri=" + encode(postLogoutRedirectUri);
    }

    private Mono<Map<String, Object>> exchangeCodeForTokens(String authCode, String codeVerifier, String redirectUri) {
        MultiValueMap<String, String> formData = new LinkedMultiValueMap<>();
        formData.add("grant_type",     "authorization_code");
        formData.add("client_id",      clientId);
        formData.add("client_secret",  clientSecret);
        formData.add("code",           authCode);
        formData.add("redirect_uri",   redirectUri);
        formData.add("code_verifier",  codeVerifier);

        return webClient.post()
                .uri(tokenEndpoint)
                .body(BodyInserters.fromFormData(formData))
                .retrieve()
                .bodyToMono(TOKEN_RESPONSE_TYPE)
                .onErrorMap(WebClientResponseException.class,
                        e -> mapTokenEndpointResponseException("Token exchange", e))
                .onErrorMap(e -> !(e instanceof InvalidStateException) && !(e instanceof AuthFlowException), e -> {
                    log.error("Unexpected error calling token exchange endpoint [{}]: {}",
                            APIErrorCode.VCPGWERR70101.getCode(), e.getMessage(), e);
                    return new AuthFlowException.OAuthTokenEndpointException(
                            APIErrorCode.VCPGWERR20104,
                            "Token endpoint unreachable during code exchange",
                            e
                    );
                });
    }

    /**
     * Logs safe, detailed diagnostics for Microsoft token endpoint HTTP errors.
     */
    private AuthFlowException.OAuthTokenEndpointException mapTokenEndpointResponseException(
            String operation,
            WebClientResponseException e
    ) {
        String responseBody = abbreviate(e.getResponseBodyAsString(StandardCharsets.UTF_8));
        Optional<String> aadstsCode = extractAadstsCode(responseBody);
        APIErrorCode errorCode = resolveTokenEndpointErrorCode(e);

        if (log.isWarnEnabled()) {
            HttpHeaders headers = e.getHeaders();
            log.warn(
                    "{} endpoint failed [{}]. aadsts='{}' status={} reason='{}' request-id='{}' correlation-id='{}' "
                            + "client-request-id='{}' www-authenticate='{}' body='{}'",
                    operation,
                    errorCode.getCode(),
                    sanitizeLogValue(aadstsCode.orElse(null)),
                    e.getStatusCode(),
                    sanitizeLogValue(e.getStatusText()),
                    sanitizeLogValue(firstHeader(headers, "x-ms-request-id", "request-id")),
                    sanitizeLogValue(firstHeader(headers, "x-ms-correlation-id", "correlation-id")),
                    sanitizeLogValue(firstHeader(headers, "client-request-id")),
                    sanitizeLogValue(headers.getFirst(HttpHeaders.WWW_AUTHENTICATE)),
                    sanitizeLogValue(responseBody),
                    e
            );
        }

        return new AuthFlowException.OAuthTokenEndpointException(
                errorCode,
                buildTokenEndpointExceptionMessage(operation, e, aadstsCode),
                e
        );
    }

    private APIErrorCode resolveTokenEndpointErrorCode(WebClientResponseException e) {
        log.warn(LOGGER_WITH_ERRCODE, APIErrorCode.VCPGWERR20104.getCode(), e.getMessage(), e);
        return APIErrorCode.VCPGWERR20104;
    }

    private String buildTokenEndpointExceptionMessage(
            String operation,
            WebClientResponseException e,
            Optional<String> aadstsCode
    ) {
        StringBuilder message = new StringBuilder(operation)
                .append(" failed: ")
                .append(e.getStatusCode());
        aadstsCode.filter(c -> !c.isBlank())
                  .ifPresent(c -> message.append(" (").append(c).append(")"));
        return message.toString();
    }

    private String firstHeader(HttpHeaders headers, String... names) {
        for (String name : names) {
            String value = headers.getFirst(name);
            if (value != null && !value.isBlank()) {
                return value;
            }
        }
        return null;
    }

    private String abbreviate(String value) {
        if (value == null || value.length() <= MAX_ERROR_BODY_LOG_LENGTH) {
            return value;
        }
        return value.substring(0, MAX_ERROR_BODY_LOG_LENGTH) + "...(truncated)";
    }

    private Optional<String> extractAadstsCode(String value) {
        if (value == null || value.isBlank()) {
            return Optional.empty();
        }
        Matcher matcher = AADSTS_ERROR_CODE_PATTERN.matcher(value);
        return matcher.find() ? Optional.of(matcher.group(1)) : Optional.empty();
    }

    private String abbreviateSessionId(String sessionId) {
        return sessionId.substring(0, Math.min(8, sessionId.length()));
    }

    private String sanitizeLogValue(String value) {
        if (value == null || value.isBlank()) {
            return "n/a";
        }
        return value.replaceAll("[\\r\\n\\t]", " ").trim();
    }

    /**
     * Decodes the JWT access token (without signature verification) and returns
     * the {@code exp} claim as an {@link Instant}.
     *
     * @param accessToken the raw JWT string
     * @return an {@link Optional} containing the expiry {@link Instant}, or empty if parsing fails
     */
    private Optional<Instant> extractExpFromAccessToken(String accessToken) {
        try {
            java.util.Date expDate = SignedJWT.parse(accessToken).getJWTClaimsSet().getExpirationTime();
            return Optional.ofNullable(expDate).map(java.util.Date::toInstant);
        } catch (Exception e) {
            log.warn("Failed to parse exp claim from access_token", e);
            return Optional.empty();
        }
    }

    private OAuthSession buildSession(Map<String, Object> tokenResponse) {
        String accessToken  = (String) tokenResponse.get("access_token");
        String refreshToken = (String) tokenResponse.get(REFRESH_TOKEN);
        String idToken      = (String) tokenResponse.get("id_token");
        Number expiresIn    = (Number) tokenResponse.get("expires_in");
        log.info("Building OAuth session with  expires in [{}] seconds",
                expiresIn);

        // A null or blank access_token indicates a malformed response from Entra ID.
        // Storing it in Redis would poison the session, causing every subsequent request
        // to forward "Authorization: Bearer null" until the session's Redis TTL expires.
        if (accessToken == null || accessToken.isBlank()) {
            log.error("Malformed token response [{}]: missing access_token", APIErrorCode.VCPGWERR20105.getCode());
            throw new AuthFlowException.MalformedTokenResponseException(
                    "Token response from Entra ID is missing the access_token field");
        }

        Optional<Instant> expOpt = extractExpFromAccessToken(accessToken);
        Instant expiresAt;
        // Fall back to expires_in from the token response when the JWT exp claim cannot be parsed.
        if (expOpt.isPresent()) {
            expiresAt = expOpt.get();
            log.info("Token response parsed:  expires_at={}", expiresAt);
        } else if (expiresIn != null) {
            expiresAt = Instant.now().plusSeconds(expiresIn.longValue());
            log.info("Token response parsed: exp claim unavailable, falling back to expires_in — expires_at={}", expiresAt);
        } else {
            // Neither JWT exp nor expires_in available — use a safe default of 3600 seconds.
            expiresAt = Instant.now().plusSeconds(3600);
            log.warn("Token response parsed: exp claim and expires_in both unavailable — defaulting to 3600s, expires_at={}", expiresAt);
        }

        return OAuthSession.builder()
                .accessToken(accessToken)
                .refreshToken(refreshToken)
                .idToken(idToken)
                .expiresAt(expiresAt)
                .build();
    }

    // ── getUserInfo ────────────────────────────────────────────────────────────

    /**
     * {@inheritDoc}
     *
     * <p>Decodes the access token stored in the session (without re-validating the
     * signature — it was already validated at the gateway filter level) and maps the
     * required claims to a {@link UserInfo} response for the dashboard.</p>
     */
    @Override
    public Mono<UserInfo> getUserInfo(WebSession session) {
        return Mono.fromCallable(() -> {
            OAuthSession oauthSession = (OAuthSession) session.getAttributes()
                    .get(SESSION_ATTR_OAUTH_SESSION);

            if (oauthSession == null) {
                throw new AuthFlowException.OAuthSessionMissingException(
                        "No active session — user is not authenticated"
                );
            }

            // Parse the access token (already signature-validated by the gateway filter).
            // Claims like DLS-Entitlements, fordUserType, fordSiteCode are in the access token.
            com.nimbusds.jwt.JWTClaimsSet claims =
                    SignedJWT.parse(oauthSession.getAccessToken()).getJWTClaimsSet();
            String fordSiteCode = claims.getStringClaim("fordSiteCode");

            @SuppressWarnings("unchecked")
            java.util.List<String> roles;
            try {
                roles = (java.util.List<String>) claims.getClaim("roles");
            } catch (ClassCastException e) {
                ClassCastException contextual = new ClassCastException(
                        "GET /auth/me — claim type mismatch while reading roles for fordSiteCode='"
                                + sanitizeLogValue(fordSiteCode) + "'"
                );
                contextual.initCause(e);
                throw contextual;
            }

            try {
                String fordUserType = claims.getStringClaim(USER_TYPE);

                // Dealer users are always role-derived from site code in downstream flows.
                // Return empty DLS-Entitlements object for dealer /dashboard/auth/me responses to maintain
                // consistent API contract while signaling no role-based entitlements apply.
                DlsEntitlements dlsEntitlements = DEALER_USER.equalsIgnoreCase(fordUserType)
                        ? new DlsEntitlements()
                        : parseDlsEntitlements(claims.getClaim(DLS_ENTITLEMENT));

                return UserInfo.builder()
                        // Critical
                        .dlsEntitlements(dlsEntitlements)
                        .fordUserType(fordUserType)
                        .fordSiteCode(fordSiteCode)
                        .countryCode(claims.getStringClaim("c"))
                        .exp(claims.getExpirationTime() != null
                                ? claims.getExpirationTime().toInstant().getEpochSecond() : null)
                        // Important
                        .givenName(claims.getStringClaim("givenName"))
                        .surname(claims.getStringClaim("sn"))
                        .sub(claims.getStringClaim("cdsid"))
                        .roles(roles)
                        .siteCode(claims.getStringClaim("siteCode"))
                        .build();
            } catch (Exception e) {
                throw new IllegalStateException(
                        "GET /auth/me — failed while mapping token claims to UserInfo for fordSiteCode='"
                                + sanitizeLogValue(fordSiteCode) + "'",
                        e
                );
            }
        }).flatMap(user -> {
            if (!DEALER_USER.equalsIgnoreCase(user.getFordUserType())) {
                return Mono.just(user);
            }
            // BE-01 already fetched and stored candidate codes during OAuth callback.
            // Absent session data (flag off / bearer token) is primary-only.
            com.careplus.gatewayservice.model.DealerPaDetails details =
                    paSessionAdapter.candidates(session, user.getFordSiteCode());
            String restored = paSessionAdapter.restoredActive(session, user.getSub());
            return dealerPaValidationService.validateDealerPaCodes(details, user.getCountryCode())
                    .map(result -> {
                        String active = restored != null && result.getAllowedPaCodes().contains(restored)
                                ? restored : result.getActivePaCode();
                        paSessionAdapter.writeAllowed(session, result.getPrimaryPaCode(),
                                result.getAllowedPaCodes(), active, user.getSub());
                        // UserInfo has no toBuilder; retain existing claims via explicit mapping.
                        return UserInfo.builder()
                                .dlsEntitlements(user.getDlsEntitlements())
                                .fordUserType(user.getFordUserType())
                                .fordSiteCode(user.getFordSiteCode())
                                .countryCode(user.getCountryCode())
                                .exp(user.getExp())
                                .givenName(user.getGivenName())
                                .surname(user.getSurname())
                                .sub(user.getSub())
                                .roles(user.getRoles())
                                .siteCode(user.getSiteCode())
                                .allowedPaCodes(result.getAllowedPaCodes())
                                .activePaCode(active)
                                .build();
                    });
        });
    }

    /**
     * Parses the raw {@code DLS-Entitlements} JWT claim value into a typed
     * {@link DlsEntitlements} object suitable for JSON serialization as an
     * <em>object</em> (not a string).
     *
     * <p>Entra ID encodes complex claims as a JSON-serialized string rather than an
     * embedded JSON object.  NimbusDS then returns the raw {@link String}, which Jackson
     * would serialize as a JSON string value — violating the OpenAPI schema that declares
     * {@code DLS-Entitlements} as {@code type: object}.</p>
     *
     * <p>If deserialization fails (malformed JSON or unexpected format), {@code null} is
     * returned so that {@code @JsonInclude(NON_NULL)} on {@link UserInfo} omits the field
     * from the response body.  This satisfies the OpenAPI schema constraint (the field is
     * not required) and prevents returning an invalid string value to the client.</p>
     *
     * @param rawClaim the raw claim value returned by NimbusDS — may be {@code null},
     *                 a {@link String}, or an already-structured {@link java.util.Map}
     * @return the parsed {@link DlsEntitlements}, or {@code null} on failure
     */
    private DlsEntitlements parseDlsEntitlements(Object rawClaim) {
        if (rawClaim == null) {
            return null;
        }
        if (rawClaim instanceof String claimStr) {
            // Entra ID encoded the claim as a JSON string — deserialise to DlsEntitlements.
            try {
                return CLAIM_OBJECT_MAPPER.readValue(claimStr, DlsEntitlements.class);
            } catch (Exception e) {
                // Do NOT return claimStr — that would produce a JSON string value and violate
                // the OpenAPI schema (type: object). Return null so the field is omitted from
                // the response (UserInfo uses @JsonInclude(NON_NULL)).
                if (log.isWarnEnabled()) {
                    String truncated = claimStr.length() > 200
                            ? claimStr.substring(0, 200) + "...(truncated)"
                            : claimStr;
                    log.warn("GET /auth/me — DLS-Entitlements claim parse failed; omitting field from response. "
                                    + "type='{}' message='{}' claimPreview='{}'",
                            e.getClass().getSimpleName(), e.getMessage(),
                            truncated.replaceAll("[\\r\\n\\t]", " "));
                }
                return null;
            }
        }
        // Already a structured object (Map, net.minidev.json.JSONObject, etc.) — convert via ObjectMapper.
        try {
            return CLAIM_OBJECT_MAPPER.convertValue(rawClaim, DlsEntitlements.class);
        } catch (Exception e) {
            log.warn("GET /auth/me — DLS-Entitlements structured claim conversion failed; "
                            + "omitting field from response. type='{}' message='{}'",
                    e.getClass().getSimpleName(), e.getMessage());
            return null;
        }
    }

    private String encode(String value) {
        return URLEncoder.encode(value, StandardCharsets.UTF_8);
    }

    /**
     * Pending authorize redirect details that are persisted before redirecting the browser.
     *
     * @param authorizeUrl built Entra authorize URL
     */
    private record PendingOAuthFlow(String authorizeUrl) {
    }
}
