package com.careplus.gatewayservice.serviceimpl;

import com.careplus.gatewayservice.model.DealerPaDetails;
import org.springframework.stereotype.Component;
import org.springframework.web.server.WebSession;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/** BE-02 adapter for BE-01's documented JDK-only Spring Session contract.
 * Replace string keys with DealerPaSessionAttributes constants once BE-01 merges.
 */
@Component
public class Be02SessionPaAdapter {
    public static final String PRIMARY = "dgl.primaryPaCode";
    public static final String CANDIDATES = "dgl.paCodes";
    public static final String STATUS = "dgl.partnerIamStatus";
    public static final String ALLOWED = "dgl.allowedPaCodes";
    public static final String ACTIVE = "dgl.activePaCode";
    public static final String VERSION = "dgl.allowedPaVersion";
    public static final String CREATED_AT = "dgl.allowedPaCreatedAt";
    public static final String OWNER = "dgl.ownerUserId";

    public DealerPaDetails candidates(WebSession session, String jwtPrimary) {
        Object raw = session.getAttributes().get(CANDIDATES);
        List<String> candidates = new ArrayList<>();
        if (raw instanceof List<?> list) {
            for (Object value : list) if (value instanceof String s) candidates.add(s);
        }
        // JWT is the source of truth for primary; BE-01's dgl.paCodes already includes it.
        return DealerPaDetails.builder().primaryPaCode(jwtPrimary).secondaryPaCodes(candidates).build();
    }

    public String restoredActive(WebSession session, String owner) {
        if (!Objects.equals(owner, session.getAttributes().get(OWNER))) return null;
        Object value = session.getAttributes().get(ACTIVE);
        return value instanceof String s ? s : null;
    }

    public void writeAllowed(WebSession session, String primary, List<String> allowed, String active, String owner) {
        session.getAttributes().put(PRIMARY, primary);
        session.getAttributes().put(ALLOWED, new ArrayList<>(allowed));
        if (active == null) session.getAttributes().remove(ACTIVE);
        else session.getAttributes().put(ACTIVE, active);
        session.getAttributes().put(VERSION, Integer.valueOf(1));
        session.getAttributes().put(CREATED_AT, Long.valueOf(System.currentTimeMillis()));
        session.getAttributes().put(OWNER, owner);
        // Do not overwrite BE-01's STATUS, CANDIDATES, or retrieval timestamp.
    }
}
