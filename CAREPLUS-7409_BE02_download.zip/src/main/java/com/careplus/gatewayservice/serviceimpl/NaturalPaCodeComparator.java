package com.careplus.gatewayservice.serviceimpl;

import java.util.Comparator;

/** Natural alphanumeric order: A2 before A10; stable tie-break for case and leading zeros. */
public final class NaturalPaCodeComparator implements Comparator<String> {
    public static final NaturalPaCodeComparator INSTANCE = new NaturalPaCodeComparator();
    private NaturalPaCodeComparator() {}

    @Override
    public int compare(String a, String b) {
        int i = 0, j = 0;
        while (i < a.length() && j < b.length()) {
            char ca = a.charAt(i), cb = b.charAt(j);
            if (isDigit(ca) && isDigit(cb)) {
                int ae = i, be = j;
                while (ae < a.length() && isDigit(a.charAt(ae))) ae++;
                while (be < b.length() && isDigit(b.charAt(be))) be++;
                int az = i, bz = j;
                while (az < ae && a.charAt(az) == '0') az++;
                while (bz < be && b.charAt(bz) == '0') bz++;
                int al = ae - az, bl = be - bz;
                if (al != bl) return Integer.compare(al, bl);
                for (int k = 0; k < al; k++) {
                    int d = Character.compare(a.charAt(az + k), b.charAt(bz + k));
                    if (d != 0) return d;
                }
                i = ae; j = be;
            } else {
                int d = Character.compare(Character.toUpperCase(ca), Character.toUpperCase(cb));
                if (d != 0) return d;
                i++; j++;
            }
        }
        if (i != a.length() || j != b.length()) return Integer.compare(a.length() - i, b.length() - j);
        return a.compareTo(b);
    }

    private static boolean isDigit(char c) { return c >= '0' && c <= '9'; }
}
