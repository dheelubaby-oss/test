package com.careplus.gatewayservice.serviceimpl;

import com.careplus.gatewayservice.exception.RedisException;
import com.careplus.gatewayservice.model.Dealer;
import com.careplus.gatewayservice.model.DealerPaDetails;
import com.careplus.gatewayservice.model.DealerPaValidationResult;
import com.careplus.gatewayservice.service.CacheService;
import com.careplus.gatewayservice.service.DealerPaValidationService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import java.util.ArrayList;
import java.util.Locale;
import java.util.regex.Pattern;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

@Service
@RequiredArgsConstructor
@Slf4j
public class DealerPaValidationServiceImpl
        implements DealerPaValidationService {

    private final CacheService cacheService;
    private final ObjectMapper objectMapper;
    private static final Pattern PA_FORMAT = Pattern.compile("^[A-Z0-9]{1,10}$");

    @Override
    public Mono<DealerPaValidationResult> validateDealerPaCodes(
            DealerPaDetails dealerPaDetails,
            String jwtCountryCode) {

        return Mono.fromCallable(() ->
                        validateDealerPaCodesInternal(
                                dealerPaDetails,
                                jwtCountryCode))
                .subscribeOn(Schedulers.boundedElastic());
    }

    private DealerPaValidationResult validateDealerPaCodesInternal(
            DealerPaDetails dealerPaDetails,
            String jwtCountryCode) {

        if (dealerPaDetails == null) {
            throw new IllegalArgumentException(
                    "Dealer PA details must not be null");
        }

        if (!StringUtils.hasText(jwtCountryCode)) {
            throw new IllegalArgumentException(
                    "JWT country code must not be blank");
        }

        String primaryPaCode = normalizePaCode(
                dealerPaDetails.getPrimaryPaCode());

        Set<String> allPaCodes = new TreeSet<>();

        addPaCode(allPaCodes, primaryPaCode);

        if (dealerPaDetails.getSecondaryPaCodes() != null) {
            dealerPaDetails.getSecondaryPaCodes()
                    .forEach(code ->
                            addPaCode(allPaCodes, normalizePaCode(code)));
        }

        List<String> allowedPaCodes = new ArrayList<>();

        for (String paCode : allPaCodes) {
            if (isEligiblePaCode(paCode, jwtCountryCode)) {
                allowedPaCodes.add(paCode);
            }
        }

        allowedPaCodes.sort(NaturalPaCodeComparator.INSTANCE);

        String activePaCode = determineActivePaCode(
                primaryPaCode,
                allowedPaCodes);

        log.info("Dealer PA validation completed. Eligible PA count: {}", allowedPaCodes.size());

        return DealerPaValidationResult.builder()
                .primaryPaCode(primaryPaCode)
                .allowedPaCodes(allowedPaCodes)
                .activePaCode(activePaCode)
                .accessAllowed(!allowedPaCodes.isEmpty())
                .build();
    }

    private boolean isEligiblePaCode(
            String paCode,
            String jwtCountryCode) {

        try {
            String dealerJson = cacheService.getDealer(paCode);

            if (!StringUtils.hasText(dealerJson)) {
                log.warn("PA candidate excluded: dealership not found");
                return false;
            }

            Dealer dealer = objectMapper.readValue(
                    dealerJson,
                    Dealer.class);

            if (dealer == null
                    || !paCode.equals(dealer.getDealerCode())
                    || !isSameCountry(
                    dealer.getCountryCode(),
                    jwtCountryCode)) {

                log.warn("PA candidate excluded: dealer or country mismatch");
                return false;
            }

            return true;

        } catch (RedisException exception) {
            log.error("Redis error while validating PA candidate", exception);
            throw new RuntimeException("Failed to validate dealer PA code in Redis", exception);

        } catch (JsonProcessingException exception) {
            log.warn("Invalid dealership Redis JSON for PA candidate", exception);
            return false;
        }
    }

    private boolean isSameCountry(
            String redisCountryCode,
            String jwtCountryCode) {

        return StringUtils.hasText(redisCountryCode)
                && redisCountryCode.trim().equalsIgnoreCase(
                jwtCountryCode.trim());
    }

    private String determineActivePaCode(
            String primaryPaCode,
            List<String> allowedPaCodes) {

        if (allowedPaCodes.isEmpty()) {
            return null;
        }

        if (allowedPaCodes.contains(primaryPaCode)) {
            return primaryPaCode;
        }

        return allowedPaCodes.get(0);
    }

    private String normalizePaCode(String paCode) {
        return paCode == null ? null : paCode.trim().toUpperCase(Locale.ROOT);
    }

    private void addPaCode(Set<String> paCodes, String paCode) {
        if (StringUtils.hasText(paCode) && paCode.matches("[A-Za-z0-9_-]{1,50}")) {
            paCodes.add(paCode);
        }
    }
}