
package com.careplus.gatewayservice.serviceimpl;

import com.careplus.gatewayservice.constant.APIErrorCode;
import com.careplus.gatewayservice.exception.RedisException;
import com.careplus.gatewayservice.model.DealerPaDetails;
import com.careplus.gatewayservice.model.DealerPaValidationResult;
import com.careplus.gatewayservice.service.CacheService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class DealerPaValidationServiceImplTest {

    @Mock
    private CacheService cacheService;

    private DealerPaValidationServiceImpl validationService;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @BeforeEach
    void setUp() {
        validationService = new DealerPaValidationServiceImpl(
                cacheService, objectMapper);
    }

    @Test
    void shouldAllowAllValidPaCodes() throws Exception {
        when(cacheService.getDealer("100"))
                .thenReturn("{\"dealerCode\":\"100\",\"countryCode\":\"USA\"}");
        when(cacheService.getDealer("200"))
                .thenReturn("{\"dealerCode\":\"200\",\"countryCode\":\"USA\"}");

        DealerPaValidationResult result = validate("100", List.of("200"));

        assertEquals(List.of("100", "200"), result.getAllowedPaCodes());
        assertEquals("100", result.getActivePaCode());
        assertTrue(result.isAccessAllowed());
    }

    @Test
    void shouldAllowSecondaryWhenPrimaryIsNotOnboarded() throws Exception {
        when(cacheService.getDealer("100")).thenReturn(null);
        when(cacheService.getDealer("200"))
                .thenReturn("{\"dealerCode\":\"200\",\"countryCode\":\"USA\"}");

        DealerPaValidationResult result = validate("100", List.of("200"));

        assertEquals(List.of("200"), result.getAllowedPaCodes());
        assertEquals("200", result.getActivePaCode());
        assertTrue(result.isAccessAllowed());
    }

    @Test
    void shouldExcludePaCodeWhenCountryDoesNotMatch() throws Exception {
        when(cacheService.getDealer("100"))
                .thenReturn("{\"dealerCode\":\"100\",\"countryCode\":\"GBR\"}");

        DealerPaValidationResult result = validate("100", Collections.emptyList());

        assertTrue(result.getAllowedPaCodes().isEmpty());
        assertFalse(result.isAccessAllowed());
        assertNull(result.getActivePaCode());
    }

    @Test
    void shouldSortPaCodesNumerically() throws Exception {
        when(cacheService.getDealer("100"))
                .thenReturn("{\"dealerCode\":\"100\",\"countryCode\":\"USA\"}");
        when(cacheService.getDealer("20"))
                .thenReturn("{\"dealerCode\":\"20\",\"countryCode\":\"USA\"}");
        when(cacheService.getDealer("3"))
                .thenReturn("{\"dealerCode\":\"3\",\"countryCode\":\"USA\"}");

        DealerPaValidationResult result = validate("100", Arrays.asList("20", "3"));

        assertEquals(List.of("3", "20", "100"), result.getAllowedPaCodes());
        assertEquals("100", result.getActivePaCode());
    }

    @Test
    void shouldExcludeMalformedRedisJson() throws Exception {
        when(cacheService.getDealer("100")).thenReturn("invalid-json");

        DealerPaValidationResult result = validate("100", Collections.emptyList());

        assertTrue(result.getAllowedPaCodes().isEmpty());
        assertFalse(result.isAccessAllowed());
    }

    @Test
    void shouldPropagateRedisFailureAsRuntimeException() throws Exception {

        when(cacheService.getDealer("100"))
                .thenThrow(new RedisException(
                        APIErrorCode.VCPGWERR70501,
                        "Redis unavailable",
                        new RuntimeException("Redis connection failed")
                ));

        RuntimeException exception = assertThrows(
                RuntimeException.class,
                () -> validationService
                        .validateDealerPaCodes(
                                DealerPaDetails.builder()
                                        .primaryPaCode("100")
                                        .secondaryPaCodes(Collections.emptyList())
                                        .build(),
                                "USA"
                        )
                        .block()
        );

        assertTrue(exception.getCause() instanceof RedisException);
    }

    @Test
    void shouldRemoveDuplicatePaCodes() throws Exception {
        when(cacheService.getDealer("100"))
                .thenReturn("{\"dealerCode\":\"100\",\"countryCode\":\"USA\"}");

        DealerPaValidationResult result = validate("100", Arrays.asList("100", "100"));

        assertEquals(List.of("100"), result.getAllowedPaCodes());
        verify(cacheService, times(1)).getDealer("100");
    }

    @Test
    void shouldSortAlphanumericNaturallyAndKeepEligiblePrimaryActive() throws Exception {
        for (String code : List.of("A10", "A2", "A1", "B1")) {
            when(cacheService.getDealer(code)).thenReturn(
                    "{\"dealerCode\":\"" + code + "\",\"countryCode\":\"USA\"}");
        }
        DealerPaValidationResult result = validate("A10", List.of("B1", "A2", "A1"));
        assertEquals(List.of("A1", "A2", "A10", "B1"), result.getAllowedPaCodes());
        assertEquals("A10", result.getActivePaCode());
    }

    private DealerPaValidationResult validate(
            String primaryPaCode, List<String> secondaryPaCodes) {

        DealerPaDetails details = DealerPaDetails.builder()
                .primaryPaCode(primaryPaCode)
                .secondaryPaCodes(secondaryPaCodes)
                .build();

        return validationService
                .validateDealerPaCodes(details, "USA")
                .block();
    }
}